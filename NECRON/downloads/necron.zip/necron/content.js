// NECRON content script
// "Smart" mode rewrites the page's own CSS colors (like Dark Reader's dynamic mode),
// so images/video/canvas are never touched. "Filter" mode is a fallback that inverts
// the page and re-inverts media.
(() => {
  'use strict';
  if (window.__necron) return;
  window.__necron = true;

  const KEY = 'necron';
  const XHTML = 'http://www.w3.org/1999/xhtml';
  const DEFAULTS = { enabled: true, mode: 'smart', brightness: 35, sites: {}, listMode: 'except', siteList: [] };
  const SKIP = new Set(['SCRIPT','STYLE','LINK','META','HEAD','TITLE','IMG','VIDEO','CANVAS','PICTURE','SOURCE',
    'IFRAME','EMBED','OBJECT','NOSCRIPT','BR','HR','AUDIO','TRACK']);
  const FORM = new Set(['INPUT','TEXTAREA','SELECT','BUTTON','OPTION']);


  // Anything you can type in (inputs, textareas, contenteditable chat boxes, role="textbox") gets readable text,
  // on every site. Text with its own inline color (e.g. red text in a rich editor) is left alone.
  const EDIT_CSS = `input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=color]):not([type=submit]):not([type=button]):not([type=file]):not([type=image]):not([type=reset]),
textarea,
[contenteditable]:not([contenteditable="false"]),
[contenteditable]:not([contenteditable="false"]) :not([style*="color"]),
[role="textbox"],
[role="textbox"] :not([style*="color"]) { color:#ececec !important; caret-color:#ececec !important; }
::placeholder { color:#8f8f8f !important; opacity:1 !important; }
`;

  // ---------- Built-in per-site fixes ----------
  const PRESETS = [
    {
      name: 'D2L / Brightspace',
      test: (h, p) => /d2l|brightspace/i.test(h) || p.startsWith('/d2l/'),
      css: `html:root, :root:root {
  --d2l-color-white:#0e0e0f !important; --d2l-color-regolith:#121213 !important;
  --d2l-color-sylvite:#161617 !important; --d2l-color-gypsum:#161617 !important;
  --d2l-color-mica:#222224 !important; --d2l-color-corundum:#3a3a3d !important;
  --d2l-color-chromite:#8b8b90 !important; --d2l-color-galena:#a9a9ae !important;
  --d2l-color-tungsten:#c9c9ce !important; --d2l-color-ferrite:#f0f0f2 !important;
  --d2l-color-celestine:#ff6b6b !important; --d2l-color-celestine-plus-1:#ff8a8a !important;
  --d2l-color-celestine-minus-1:#ff5252 !important;
}
d2l-card, .d2l-card-container, .d2l-tile, .d2l-tiles-container { background-color:#0e0e0f !important; }`,
      // injected inside every shadow root (cards, dropdowns, widgets live there)
      shadowCss: `d2l-card, .d2l-card-container, .d2l-card-footer-hover, .d2l-tile,
d2l-dropdown-content, d2l-dropdown-menu, d2l-menu, d2l-menu-item,
.d2l-dropdown-content-pointer, .d2l-dropdown-content-container, .d2l-dropdown-content-width,
.d2l-dropdown-content-top, .d2l-dropdown-content-bottom { background-color:#0e0e0f !important; }
d2l-card, .d2l-card-container { border-color:#2a2a2d !important; }`
    },
    {
      name: 'Google Docs',
      test: (h, p) => h === 'docs.google.com' && p.indexOf('/document/') === 0,
      // Only applies once the canvas hook has confirmed it can recolor text, so text is never lost.
      css: `html[data-necron-canvas] [class*="kix-page"],
html[data-necron-canvas] .kix-canvas-tile-content,
html[data-necron-canvas] .kix-page-paginated
{ background-color:#0b0b0b !important; }
/* typing cursor: black by default, so make it white (other people's colored cursors stay colored) */
[class*="kix-cursor-caret"]:not([style*="rgb("]),
[class*="kix-cursor-caret"][style*="rgb(0, 0, 0)"],
[class*="kix-cursor-caret"][style*="rgb(0,0,0)"],
[class*="kix-cursor-caret"][style*="#000"]
{ border-color:#ffffff !important; border-left-color:#ffffff !important; background-color:#ffffff !important; caret-color:#ffffff !important; }`
    },
    {
      name: 'Gemini',
      test: (h) => h === 'gemini.google.com',
      css: `.ql-editor, .ql-editor p, .ql-editor li { color:#ececec !important; caret-color:#ececec !important; }
.ql-editor.ql-blank::before { color:#9a9a9a !important; }`
    },
    {
      name: 'GitHub',
      test: (h) => /(^|\.)github\.com$/i.test(h),
      css: '',
      // GitHub ships a full dark theme; flip it on instead of recoloring everything by hand.
      attrs: { 'data-color-mode': 'dark', 'data-dark-theme': 'dark', 'data-light-theme': 'dark' }
    },
    {
      name: 'GPTZero',
      test: (h) => /(^|\.)gptzero\.me$/i.test(h),
      css: `textarea, [contenteditable="true"] { caret-color:#f0f0f0 !important; }`
    }
  ];

  // ---------- State ----------
  let settings = DEFAULTS;
  let cfg = null;
  let active = false;
  let version = 0;
  let pollTimer = null;
  const roots = new Map(); // Document|ShadowRoot -> state
  const pending = new Set();
  let scanTimer = null;
  const inlineStore = new WeakMap();
  let origAttrs = {};

  function topHost() {
    try {
      const ao = location.ancestorOrigins;
      if (ao && ao.length) return new URL(ao[ao.length - 1]).hostname;
    } catch (e) {}
    return location.hostname;
  }
  const HOST = topHost();
  const siteKey = (h) => String(h).split('.').slice(-2).join('.');
  // Small embedded frames from other sites (chat launchers, captchas, payment boxes) are left alone.
  // Big frames from other sites (like an exam or course page) are still made dark.
  const IS_CROSS_SITE = (() => {
    try {
      if (window.top === window.self) return false;
      if (!/^https?:$/.test(location.protocol)) return false;
      const ao = location.ancestorOrigins;
      if (!ao || !ao.length) return false;
      return siteKey(location.hostname) !== siteKey(new URL(ao[ao.length - 1]).hostname);
    } catch (e) { return false; }
  })();
  const smallFrame = () => (window.innerWidth || 0) < 520 || (window.innerHeight || 0) < 320;
  const skipFrame = () => IS_CROSS_SITE && smallFrame();

  // Site list matching (same rules as the popup). "google.com", "google.com/maps", "*.example.com"
  function normPat(p) { return String(p).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/+$/, ''); }
  function matchesPat(entry, h, pth) {
    const p = normPat(entry);
    if (!p) return false;
    const i = p.indexOf('/');
    const ph = (i < 0 ? p : p.slice(0, i)).replace(/^www\./, '');
    const pp = i < 0 ? '' : p.slice(i);
    h = h.replace(/^www\./, '');
    const ok = ph.indexOf('*.') === 0 ? (h === ph.slice(2) || h.endsWith('.' + ph.slice(2))) : h === ph;
    if (!ok) return false;
    return !pp || (pth || '').toLowerCase().indexOf(pp) === 0;
  }
  function siteAllowed() {
    const list = Array.isArray(settings.siteList) ? settings.siteList : [];
    const pth = location.hostname === HOST ? location.pathname : '';
    const listed = list.some((e) => matchesPat(e, HOST, pth));
    return settings.listMode === 'only' ? listed : !listed;
  }

  function resolve() {
    const s = (settings.sites || {})[HOST] || {};
    const mode = 'smart'; // Smart is the only mode
    // Built-in dark fixes are for Smart mode only; under Filter they'd be inverted back to light.
    const preset = mode === 'smart' ? PRESETS.find((p) => p.test(HOST, location.pathname)) : null;
    const brightness = typeof settings.brightness === 'number' ? settings.brightness : 35;
    return {
      enabled: settings.enabled !== false && s.enabled !== false && siteAllowed() && !skipFrame(),
      mode: 'smart',
      base: 0.05 + (brightness / 100) * 0.15,
      brightness,
      css: preset ? preset.css : '',
      shadowCss: preset && preset.shadowCss ? preset.shadowCss : '',
      attrs: preset && preset.attrs ? preset.attrs : null
    };
  }

  // ---------- Color helpers ----------
  const colorCache = new Map();
  let ctx2d = null;
  const RGB_RE = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:\s*[,/]\s*([\d.]+)(%?))?\s*\)$/;

  function parseColor(str) {
    if (!str) return null;
    str = String(str).trim().toLowerCase();
    if (colorCache.has(str)) return colorCache.get(str);
    if (colorCache.size > 6000) colorCache.clear();
    let res = null;
    if (str === 'transparent') res = [0, 0, 0, 0];
    else if (/var\(|inherit|initial|unset|currentcolor|revert|none|env\(|calc\(/.test(str)) res = null;
    else {
      let m = str.match(RGB_RE);
      if (!m) {
        try {
          if (!ctx2d) ctx2d = document.createElement('canvas').getContext('2d');
          ctx2d.fillStyle = '#010203';
          ctx2d.fillStyle = str;
          const v = ctx2d.fillStyle;
          if (v !== '#010203') {
            if (v[0] === '#') {
              res = [parseInt(v.slice(1, 3), 16), parseInt(v.slice(3, 5), 16), parseInt(v.slice(5, 7), 16), 1];
            } else m = v.match(RGB_RE);
          }
        } catch (e) {}
      }
      if (m && !res) res = [+m[1], +m[2], +m[3], m[4] === undefined ? 1 : (m[5] ? +m[4] / 100 : +m[4])];
    }
    colorCache.set(str, res);
    return res;
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    let h = 0, s = 0;
    if (d) {
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return [h, s, l];
  }
  const hsl = (h, s, l, a) =>
    `hsla(${h.toFixed(0)},${(Math.min(1, s) * 100).toFixed(1)}%,${(Math.min(1, Math.max(0, l)) * 100).toFixed(1)}%,${a})`;

  // Light backgrounds -> dark
  function tBg(c) {
    if (c[3] < 0.05) return null;
    const [h, s, l] = rgbToHsl(c[0], c[1], c[2]);
    if (l <= 0.5) return null;
    return hsl(h, s * 0.85, cfg.base + (1 - l) * 0.4, c[3]);
  }
  // Dark text/icons -> light
  function tText(c) {
    if (c[3] < 0.05) return null;
    const [h, s, l] = rgbToHsl(c[0], c[1], c[2]);
    if (l >= 0.6) return null;
    return hsl(h, s * 0.9, 0.9 - l * 0.45, c[3]);
  }
  // Light borders -> dark
  function tBorder(c) {
    if (c[3] < 0.05) return null;
    const [h, s, l] = rgbToHsl(c[0], c[1], c[2]);
    if (l <= 0.5) return null;
    return hsl(h, s * 0.8, 0.2 + (1 - l) * 0.4, c[3]);
  }
  const FN = { bg: tBg, text: tText, bd: tBorder };
  const PROPS = {
    'background-color': 'bg',
    'color': 'text', 'fill': 'text', 'stroke': 'text', 'text-decoration-color': 'text',
    'border-top-color': 'bd', 'border-right-color': 'bd', 'border-bottom-color': 'bd',
    'border-left-color': 'bd', 'outline-color': 'bd'
  };
  const COLOR_TOKEN = /#[0-9a-f]{3,8}\b|rgba?\([^)]*\)|hsla?\([^)]*\)/gi;

  function transformGradient(v) {
    if (!/gradient\(/i.test(v) || /url\(/i.test(v)) return null;
    let changed = false;
    const out = v.replace(COLOR_TOKEN, (tok) => {
      const c = parseColor(tok);
      const n = c && tBg(c);
      if (n) { changed = true; return n; }
      return tok;
    });
    return changed ? out : null;
  }

  // ---------- CSS rewriting ----------
  function varKind(name) {
    const n = name.toLowerCase();
    if (/(^|[-_])on[-_]/.test(n)) return 'text';
    if (/border|outline|divider|stroke|separator/.test(n)) return 'bd';
    if (/(^|[-_])(bg|background|surface|canvas|backdrop|overlay)|bgcolor|background/.test(n)) return 'bg';
    if (/(^|[-_])(fg|text|foreground|ink|icon)|fgcolor|textcolor/.test(n)) return 'text';
    return null;
  }

  function ruleListText(rules) {
    let out = '';
    for (const rule of rules) {
      try {
        if (rule.type === 1) {
          const st = rule.style, decl = [];
          for (const prop in PROPS) {
            const v = st.getPropertyValue(prop);
            if (!v) continue;
            const c = parseColor(v);
            const nv = c && FN[PROPS[prop]](c);
            if (nv) decl.push(`${prop}:${nv}!important`);
          }
          for (let i = 0; i < st.length; i++) {
            const name = st[i];
            if (name.charCodeAt(0) !== 45 || name.charCodeAt(1) !== 45) continue;
            const kind = varKind(name);
            if (!kind) continue;
            const c = parseColor(st.getPropertyValue(name));
            const nv = c && FN[kind](c);
            if (nv) decl.push(`${name}:${nv}!important`);
          }
          const bi = st.getPropertyValue('background-image');
          if (bi) { const g = transformGradient(bi); if (g) decl.push(`background-image:${g}!important`); }
          if (decl.length) out += `${rule.selectorText}{${decl.join(';')}}\n`;
        } else if (rule.type === 3) {
          if (rule.styleSheet) out += ruleListText(rule.styleSheet.cssRules);
        } else if (rule.cssRules) {
          const inner = ruleListText(rule.cssRules);
          if (!inner) continue;
          if (rule.constructor && rule.constructor.name === 'CSSLayerBlockRule') { out += inner; continue; }
          const t = rule.cssText;
          out += `${t.slice(0, t.indexOf('{'))}{${inner}}\n`;
        }
      } catch (e) {}
    }
    return out;
  }

  const sheetCache = new WeakMap();
  const remoteCache = new Map();

  function getRemoteSheet(href) {
    if (!/^https?:/i.test(href)) return Promise.resolve(null);
    if (remoteCache.has(href)) return remoteCache.get(href);
    const p = new Promise((resolveP) => {
      try {
        chrome.runtime.sendMessage({ type: 'fetchCss', url: href }, (res) => {
          if (chrome.runtime.lastError || !res || !res.ok) return resolveP(null);
          try {
            const s = new CSSStyleSheet();
            s.replaceSync(res.text);
            resolveP(s);
          } catch (e) { resolveP(null); }
        });
      } catch (e) { resolveP(null); }
    });
    remoteCache.set(href, p);
    return p;
  }

  async function resolveSheets(root) {
    const list = [];
    const all = Array.from(root.styleSheets || []).concat(Array.from(root.adoptedStyleSheets || []));
    for (const sh of all) {
      const node = sh.ownerNode;
      if (node && node.hasAttribute && node.hasAttribute('data-necron')) continue;
      if (sh.disabled) continue;
      try {
        void sh.cssRules.length;
        list.push(sh);
      } catch (e) {
        if (sh.href) { const r = await getRemoteSheet(sh.href); if (r) list.push(r); }
      }
    }
    return list;
  }

  async function rebuild(root) {
    const st = roots.get(root);
    if (!st || !active || cfg.mode !== 'smart') return;
    if (st.busy) { st.again = true; return; }
    st.busy = true;
    try {
      const sheets = await resolveSheets(root);
      let text = '', sig = '';
      for (const sh of sheets) {
        let len;
        try { len = sh.cssRules.length; } catch (e) { continue; }
        sig += len + ',';
        let c = sheetCache.get(sh);
        if (!c || c.len !== len || c.v !== version) {
          c = { len, v: version, text: ruleListText(sh.cssRules) };
          sheetCache.set(sh, c);
        }
        text += c.text;
      }
      if (active && (sig !== st.sig || st.v !== version)) {
        st.sig = sig; st.v = version;
        st.style.textContent = text;
        placeLast(root, st.style);
      }
    } finally {
      st.busy = false;
      if (st.again) { st.again = false; rebuild(root); }
    }
  }

  function scheduleRebuild(root) {
    const st = roots.get(root);
    if (!st) return;
    clearTimeout(st.rt);
    st.rt = setTimeout(() => rebuild(root), 80);
  }

  function container(root) { return root.nodeType === 9 ? root.documentElement : root; }
  function placeLast(root, el) {
    const c = container(root);
    if (c && c.lastChild !== el) c.appendChild(el);
  }
  function makeStyle(css) {
    const s = document.createElement('style');
    s.setAttribute('data-necron', '');
    if (css) s.textContent = css;
    return s;
  }

  // ---------- Inline fallback (catches var()-based colors, inline styles, etc.) ----------
  function setInline(el, prop, val) {
    let st = inlineStore.get(el);
    if (!st) { st = {}; inlineStore.set(el, st); el.setAttribute('data-necron-i', ''); }
    if (!(prop in st)) st[prop] = [el.style.getPropertyValue(prop), el.style.getPropertyPriority(prop)];
    el.style.setProperty(prop, val, 'important');
  }

  function effBgL(el, memo) {
    const visited = [];
    let cur = el, res = 0.08;
    while (cur && cur.nodeType === 1 && visited.length < 40) {
      if (memo.has(cur)) { res = memo.get(cur); break; }
      visited.push(cur);
      const cs = getComputedStyle(cur);
      const c = parseColor(cs.backgroundColor);
      if (c && c[3] > 0.5) { res = rgbToHsl(c[0], c[1], c[2])[2]; break; }
      if (cs.backgroundImage.indexOf('url(') !== -1) { res = 0.5; break; }
      cur = cur.parentElement || (cur.getRootNode && cur.getRootNode().host);
    }
    for (const v of visited) memo.set(v, res);
    return res;
  }

  function hasOwnText(el) {
    for (let n = el.firstChild; n; n = n.nextSibling) if (n.nodeType === 3 && n.nodeValue.trim()) return true;
    return false;
  }

  const IS_DOCS = HOST === 'docs.google.com';
  // Google Docs' typing cursor is black by default; make it white. Other people's colored cursors keep their color.
  function fixCaret(el) {
    const cs = getComputedStyle(el);
    const dark = (v) => { const c = parseColor(v); return c && c[3] > 0.3 && rgbToHsl(c[0], c[1], c[2])[2] < 0.3; };
    if (dark(cs.borderLeftColor) || dark(cs.borderTopColor) || dark(cs.borderRightColor) || dark(cs.borderBottomColor)) {
      setInline(el, 'border-color', '#ffffff');
    }
    if (dark(cs.backgroundColor)) setInline(el, 'background-color', '#ffffff');
  }

  function fixSmart(el, memo) {
    if (IS_DOCS && typeof el.className === 'string' && el.className.indexOf('kix-cursor-caret') !== -1) { fixCaret(el); return; }
    const cs = getComputedStyle(el);
    const bg = parseColor(cs.backgroundColor);
    if (bg && bg[3] > 0.35) {
      const v = tBg(bg);
      if (v) { setInline(el, 'background-color', v); memo.delete(el); }
    }
    const editable = el.isContentEditable === true;
    if (editable || FORM.has(el.tagName) || hasOwnText(el)) {
      const col = parseColor(cs.color);
      const v = col && tText(col);
      if (v && effBgL(el, memo) < (editable ? 0.62 : 0.45)) setInline(el, 'color', v);
      // Guard: light text sitting on a still-light solid background -> darken that background.
      if (col && col[3] > 0.5 && rgbToHsl(col[0], col[1], col[2])[2] > 0.7 && effBgL(el, memo) > 0.62) {
        let cur = el;
        for (let i = 0; cur && cur.nodeType === 1 && i < 40; i++) {
          const cc = getComputedStyle(cur);
          const bc = parseColor(cc.backgroundColor);
          if (bc && bc[3] > 0.5) {
            const nv = tBg(bc);
            if (nv) { setInline(cur, 'background-color', nv); memo.clear(); }
            break;
          }
          cur = cur.parentElement || (cur.getRootNode && cur.getRootNode().host);
        }
      }
    }
  }

  function fixFilter(el) {
    if (el.children.length) return;
    const cs = getComputedStyle(el);
    if (cs.backgroundImage.indexOf('url(') !== -1 && !inlineStore.has(el)) {
      setInline(el, 'filter', 'invert(1) hue-rotate(180deg)');
    }
  }

  function processOne(el, memo) {
    if (!el.isConnected) return;
    if (el.shadowRoot) attachRoot(el.shadowRoot);
    if (el.tagName === 'IFRAME') {
      try {
        const u = new URL(el.getAttribute('src') || '', location.href);
        if (/^https?:$/.test(u.protocol) && siteKey(u.hostname) !== siteKey(location.hostname)) setInline(el, 'color-scheme', 'light');
      } catch (e) {}
      return;
    }
    if (el.namespaceURI !== XHTML || SKIP.has(el.tagName)) return;
    try { cfg.mode === 'smart' ? fixSmart(el, memo) : fixFilter(el); } catch (e) {}
  }
  function flushScan() {
    scanTimer = null;
    if (!active) return;
    const memo = new Map();
    const t0 = performance.now();
    for (const el of pending) {
      pending.delete(el);
      processOne(el, memo);
      if (performance.now() - t0 > 12) break;
    }
    if (pending.size) scanTimer = setTimeout(flushScan, 20);
  }
  function queueScan(els) {
    for (const el of els) pending.add(el);
    if (!scanTimer && pending.size) scanTimer = setTimeout(flushScan, 30);
  }
  function queueTree(node) {
    if (node.nodeType === 1) pending.add(node);
    if (node.querySelectorAll) for (const el of node.querySelectorAll('*')) pending.add(el);
    if (!scanTimer && pending.size) scanTimer = setTimeout(flushScan, 30);
  }

  function onEditInput(e) {
    if (!active || !cfg || cfg.mode !== 'smart') return;
    const t = e.target;
    if (!t || t.nodeType !== 1) return;
    const host = (t.closest && t.closest('[contenteditable]')) || t;
    const memo = new Map();
    processOne(host, memo);
    let n = 0;
    for (const d of host.querySelectorAll('*')) { processOne(d, memo); if (++n > 80) break; }
  }

  // ---------- Roots (document + shadow roots) ----------
  const MEDIA_CSS = `img,video,canvas,embed,object{filter:invert(1) hue-rotate(180deg)!important}`;

  // Sites fade colors when a header/menu changes on scroll. With our overrides that fade can pass
  // through white, so color transitions are finished instantly in Smart mode.
  const COLOR_TRANS = new Set(['background-color', 'background', 'background-image', 'color', 'fill', 'stroke',
    'border-color', 'border-top-color', 'border-right-color', 'border-bottom-color', 'border-left-color',
    'outline-color', 'box-shadow', 'filter', 'backdrop-filter', 'opacity']);
  function onTransitionRun(e) {
    if (!active || !cfg || cfg.mode !== 'smart' || !COLOR_TRANS.has(e.propertyName)) return;
    if (e.propertyName === 'opacity' || e.propertyName === 'filter') return;
    try {
      for (const a of e.target.getAnimations()) if (a.transitionProperty === e.propertyName) a.finish();
    } catch (err) {}
  }

  function attachRoot(root) {
    if (!active || roots.has(root)) return;
    const c = container(root);
    if (!c) return;
    const style = makeStyle(cfg.mode === 'filter' ? MEDIA_CSS : '');
    c.appendChild(style);
    const st = { style, sig: '', v: -1, busy: false };
    if (root.nodeType === 11 && cfg.mode === 'smart') { st.extra = makeStyle((cfg.shadowCss || '') + EDIT_CSS); c.appendChild(st.extra); }
    st.onload = (e) => { if (e.target && e.target.tagName === 'LINK') scheduleRebuild(root); };
    root.addEventListener('load', st.onload, true);
    root.addEventListener('transitionrun', onTransitionRun, true);
    root.addEventListener('input', onEditInput, true);
    root.addEventListener('focusin', onEditInput, true);
    st.observer = new MutationObserver((muts) => onMut(muts, root));
    st.observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'data-color-mode', 'data-dark-theme', 'data-light-theme'] });
    roots.set(root, st);
    if (cfg.mode === 'smart') rebuild(root);
    queueTree(root.nodeType === 9 ? root.documentElement : root);
  }

  function onMut(muts, root) {
    if (!active) return;
    let rebuildNeeded = false;
    // New/changed nodes are fixed right here (before the browser paints) so nothing flashes white.
    const imm = [];
    const take = (el) => { if (imm.length < 250) imm.push(el); else pending.add(el); };
    for (const m of muts) {
      const t = m.target;
      if (t.nodeType === 1 && t.hasAttribute('data-necron')) continue;
      if (m.type === 'childList') {
        if (t.tagName === 'STYLE') rebuildNeeded = true;
        for (const n of m.removedNodes) if (n.nodeType === 1 && (n.tagName === 'STYLE' || n.tagName === 'LINK')) rebuildNeeded = true;
        for (const n of m.addedNodes) {
          if (n.nodeType !== 1 || n.hasAttribute('data-necron')) continue;
          if (n.tagName === 'STYLE' || n.tagName === 'LINK') rebuildNeeded = true;
          take(n);
          for (const e of n.querySelectorAll('*')) take(e);
        }
      } else if (t.nodeType === 1) {
        if (cfg.attrs && t === document.documentElement && cfg.attrs[m.attributeName] !== undefined) {
          if (t.getAttribute(m.attributeName) !== cfg.attrs[m.attributeName]) t.setAttribute(m.attributeName, cfg.attrs[m.attributeName]);
        } else take(t);
      }
    }
    if (imm.length) { const memo = new Map(); for (const el of imm) processOne(el, memo); }
    if (pending.size && !scanTimer) scanTimer = setTimeout(flushScan, 30);
    if (rebuildNeeded) scheduleRebuild(root);
  }

  function discoverShadows() {
    for (const root of Array.from(roots.keys())) {
      if (typeof root !== 'object') continue; // 'base' / 'custom' are style entries, not roots
      for (const el of root.querySelectorAll('*')) if (el.shadowRoot) attachRoot(el.shadowRoot);
    }
  }
  let discTimer = null;
  document.addEventListener('necron-shadow', () => {
    if (!active || discTimer) return;
    discTimer = setTimeout(() => { discTimer = null; if (active) discoverShadows(); }, 150);
  });

  // ---------- Apply / teardown ----------
  function baseCss() {
    if (cfg.mode === 'filter') {
      const bri = (0.8 + (cfg.brightness / 100) * 0.4).toFixed(2);
      return `html{background:#e8e6e3!important;filter:invert(1) hue-rotate(180deg) brightness(${bri}) contrast(0.92)!important}
${MEDIA_CSS}
::selection{background:#8b1a22!important;color:#fff!important}`;
    }
    return `:root{color-scheme:dark!important}
html{background-color:#181a1b}
::selection{background:#8b1a22!important;color:#fff!important}
html{scrollbar-color:#4a5053 #1f2224}
${EDIT_CSS}`;
  }

  function apply() {
    teardown();
    cfg = resolve();
    if (!cfg.enabled) return;
    if (!document.documentElement) { setTimeout(apply, 5); return; }
    active = true;
    version++;
    if (cfg.mode === 'smart') document.documentElement.setAttribute('data-necron-on', '');
    if (cfg.attrs) {
      const de = document.documentElement;
      for (const k in cfg.attrs) { if (!(k in origAttrs)) origAttrs[k] = de.getAttribute(k); de.setAttribute(k, cfg.attrs[k]); }
    }
    const base = makeStyle(baseCss());
    base.id = 'necron-base';
    document.documentElement.appendChild(base);
    roots.set('base', { style: base, observer: { disconnect() {} } });
    attachRoot(document);
    if (cfg.css.trim()) {
      const custom = makeStyle(cfg.css);
      custom.id = 'necron-custom';
      document.documentElement.appendChild(custom);
      roots.set('custom', { style: custom, observer: { disconnect() {} } });
    }
    [1200, 3500, 8000].forEach((ms) => setTimeout(() => {
      if (!active || cfg.mode !== 'smart') return;
      for (const r of roots.keys()) if (typeof r === 'object') queueTree(r.nodeType === 9 ? r.documentElement : r);
    }, ms));
    let tick = 0;
    pollTimer = setInterval(() => {
      if (document.hidden) return;
      tick++;
      for (const r of roots.keys()) if (typeof r === 'object') scheduleRebuild(r);
      if (tick % 4 === 0) discoverShadows();
      const base = roots.get('base'), custom = roots.get('custom');
      if (base && base.style.nextSibling) document.documentElement.appendChild(base.style);
      if (custom && custom.style.nextSibling) document.documentElement.appendChild(custom.style);
    }, 2000);
  }

  function teardown() {
    active = false;
    clearInterval(pollTimer);
    clearTimeout(scanTimer);
    scanTimer = null;
    pending.clear();
    for (const [root, st] of roots) {
      if (typeof root === 'object') {
        try {
          for (const el of root.querySelectorAll('[data-necron-i]')) {
            const saved = inlineStore.get(el);
            if (saved) for (const p in saved) {
              if (saved[p][0]) el.style.setProperty(p, saved[p][0], saved[p][1]);
              else el.style.removeProperty(p);
            }
            inlineStore.delete(el);
            el.removeAttribute('data-necron-i');
          }
        } catch (e) {}
        root.removeEventListener('load', st.onload, true);
        root.removeEventListener('transitionrun', onTransitionRun, true);
        root.removeEventListener('input', onEditInput, true);
        root.removeEventListener('focusin', onEditInput, true);
      }
      st.observer.disconnect();
      st.style.remove();
      if (st.extra) st.extra.remove();
    }
    roots.clear();
    try {
      const de = document.documentElement;
      de.removeAttribute('data-necron-on');
      for (const k in origAttrs) { if (origAttrs[k] === null) de.removeAttribute(k); else de.setAttribute(k, origAttrs[k]); }
    } catch (e) {}
    origAttrs = {};
  }

  // ---------- Settings ----------
  function load(cb) {
    try {
      chrome.storage.local.get(KEY, (r) => {
        settings = Object.assign({}, DEFAULTS, (r && r[KEY]) || {});
        settings.sites = settings.sites || {};
        cb();
      });
    } catch (e) { cb(); }
  }
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[KEY]) load(apply);
    });
  } catch (e) {}

  if (window.top === window.self && /^https?:$/.test(location.protocol)) {
    try { chrome.runtime.sendMessage({ type: 'seen', host: location.hostname }); } catch (e) {}
  }
  load(apply);
})();
