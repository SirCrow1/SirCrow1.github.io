# Necron

Dark mode extension (Chrome / Edge / Brave, Manifest V3).

## Install
1. Unzip this folder.
2. Open `chrome://extensions`, enable **Developer mode**.
3. **Load unpacked** and select the `necron` folder. (If you already loaded an older copy, press the reload icon on its card.)

On by default for every site. Toggle with the popup or **Alt+Shift+N**.

## Modes
- **Smart** (default): rewrites the page's own CSS colors, including shadow DOM and cross-origin stylesheets.
  Images, video and canvas content are never touched.
- **Filter**: invert + hue-rotate fallback, with images/video/canvas flipped back.

## Built-in site fixes
Live in the `PRESETS` array at the top of `content.js`:
- D2L / Brightspace: recolors its palette variables and force-darkens cards and dropdowns inside shadow DOM.
- Google Docs: recolors what the document canvas draws (text, lines, page fill) but not `drawImage`, so pictures stay normal.
  Reload the Doc after toggling Necron.
- GPTZero.
