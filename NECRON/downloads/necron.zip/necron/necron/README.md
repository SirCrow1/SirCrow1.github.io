# Necron

Dark mode extension (Chrome / Edge / Brave, Manifest V3).

## Install
1. Unzip this folder.
2. Open `chrome://extensions`, enable **Developer mode**.
3. **Load unpacked** and select the `necron` folder. (If you already loaded an older copy, press the reload icon on its card.)

On by default for every site. Toggle with the popup or **Alt+Shift+N**.

## How it works
Necron rewrites each page's own colors to dark, so images and video stay normal.
There's nothing to pick: turn Necron on or off for everything (top switch) or per site (Main tab, or the On/Off buttons in the Site list tab).

## Built-in site fixes
Live in the `PRESETS` array at the top of `content.js`:
- D2L / Brightspace: recolors its palette variables and force-darkens cards and dropdowns inside shadow DOM.
- Google Docs: recolors what the document canvas draws (text, lines, page fill) but not `drawImage`, so pictures stay normal.
  Reload the Doc after toggling Necron.
- GPTZero.

## Your own logo
Put a square PNG named `logo.png` (about 64x64) in the `necron` folder, next to `popup.html`.
It shows at the top-left of the popup. If the file isn't there, nothing is shown.
