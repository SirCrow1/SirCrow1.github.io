const KEY = 'necron';

// Content scripts can't read cross-origin stylesheets, so they ask us to fetch them.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'seen' && typeof msg.host === 'string' && msg.host) {
    chrome.storage.local.get('necron_seen', (r) => {
      let list = Array.isArray(r.necron_seen) ? r.necron_seen : [];
      if (list[0] === msg.host) return;
      list = [msg.host].concat(list.filter((h) => h !== msg.host)).slice(0, 300);
      chrome.storage.local.set({ necron_seen: list });
    });
    return;
  }
  if (msg && msg.type === 'fetchCss' && /^https?:/i.test(msg.url || '')) {
    fetch(msg.url, { credentials: 'include' })
      .then((r) => (r.ok ? r.text() : Promise.reject(new Error('bad status'))))
      .then((text) => sendResponse({ ok: true, text }))
      .catch(() => sendResponse({ ok: false }));
    return true; // async response
  }
});

async function getSettings() {
  const r = await chrome.storage.local.get(KEY);
  return Object.assign({ enabled: true, mode: 'smart', brightness: 35, sites: {} }, r[KEY] || {});
}

chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== 'toggle-necron') return;
  const s = await getSettings();
  s.enabled = !s.enabled;
  await chrome.storage.local.set({ [KEY]: s });
});

function updateBadge(s) {
  chrome.action.setBadgeText({ text: s.enabled ? '' : 'OFF' });
  chrome.action.setBadgeBackgroundColor({ color: '#444' });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[KEY]) updateBadge(Object.assign({ enabled: true }, changes[KEY].newValue || {}));
});
chrome.runtime.onStartup.addListener(async () => updateBadge(await getSettings()));
chrome.runtime.onInstalled.addListener(async () => updateBadge(await getSettings()));
