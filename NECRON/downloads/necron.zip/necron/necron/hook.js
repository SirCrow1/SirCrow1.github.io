// Runs in the PAGE world. Makes shadow roots (used by D2L/Brightspace and many
// web-component sites) visible to Necron so they can be themed too.
(() => {
  const orig = Element.prototype.attachShadow;
  if (!orig || orig.__necron) return;
  const patched = function () {
    const root = orig.apply(this, arguments);
    // Only a signal; the page's elements and arguments are left completely untouched.
    try { document.dispatchEvent(new Event('necron-shadow')); } catch (e) {}
    return root;
  };
  try { Object.defineProperty(patched, 'name', { value: 'attachShadow' }); } catch (e) {}
  patched.__necron = true;
  Element.prototype.attachShadow = patched;
})();

// Google Docs draws the document on a <canvas>. Recolor only the TEXT/LINES/PAGE fills that
// Docs draws, never drawImage(), so pictures keep their real colors.
(() => {
  if (location.hostname !== 'docs.google.com' || location.pathname.indexOf('/document/') !== 0) return;
  const root = document.documentElement;
  let on = root.hasAttribute('data-necron-on');
  // Docs paints the page once and caches it, so after Necron is switched on/off the old tiles stay
  // as they were. Nudge Docs to re-layout and repaint so the change shows without a refresh.
  function repaint() {
    try { window.dispatchEvent(new Event('resize')); } catch (e) {}
    try {
      const sc = document.querySelector('.kix-appview-editor');
      if (sc) { const t = sc.scrollTop; sc.scrollTop = t + 1; requestAnimationFrame(() => { sc.scrollTop = t; }); }
    } catch (e) {}
  }
  new MutationObserver(() => {
    const now = root.hasAttribute('data-necron-on');
    if (now === on) return;
    on = now;
    setTimeout(repaint, 60);
    setTimeout(repaint, 500);
    setTimeout(repaint, 1500);
  }).observe(root, { attributes: true, attributeFilter: ['data-necron-on'] });

  const parse = (v) => {
    if (typeof v !== 'string') return null;
    let m = /^#([0-9a-f]{6})$/i.exec(v);
    if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, 1]; }
    m = /^rgba?\(([^)]+)\)$/.exec(v);
    if (m) { const p = m[1].split(/[\s,\/]+/).map(Number); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1]; }
    return null;
  };
  const lum = (c) => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
  const lighten = (c) => {
    const mx = Math.max(c[0], c[1], c[2]), mn = Math.min(c[0], c[1], c[2]);
    if (mx - mn < 40) return '#ececec';
    const k = 0.6, f = (x) => Math.round(x + (255 - x) * k);
    return `rgba(${f(c[0])},${f(c[1])},${f(c[2])},${c[3]})`;
  };
  let flagged = false;
  const flag = () => { if (!flagged) { flagged = true; root.setAttribute('data-necron-canvas', ''); } };

  // New tiles are transparent until drawn; keep what's behind them dark so scrolling never flashes white.
  const painted = new WeakSet();
  function backdrop(cv) {
    try {
      let el = cv, n = 0;
      while (el && el !== document.body && n < 5) {
        if (!painted.has(el)) { painted.add(el); el.style.setProperty('background-color', '#0b0b0b', 'important'); }
        el = el.parentElement; n++;
      }
    } catch (e) {}
  }

  function wrap(name, prop, mode) {
    const P = CanvasRenderingContext2D.prototype, orig = P[name];
    if (!orig) return;
    P[name] = function () {
      if (!on) return orig.apply(this, arguments);
      const prev = this[prop], c = parse(prev);
      let swap = null;
      if (c && c[3] > 0.05) {
        const L = lum(c);
        if (mode === 'text' || mode === 'line') { if (L < 0.45) swap = lighten(c); }
        else if (mode === 'shape') { if (L > 0.92) swap = '#0b0b0b'; else if (L < 0.3) swap = lighten(c); }
      }
      if (swap === null) return orig.apply(this, arguments);
      flag();
      if (mode === 'shape') backdrop(this.canvas);
      this[prop] = swap;
      try { return orig.apply(this, arguments); } finally { this[prop] = prev; }
    };
  }
  wrap('fillText', 'fillStyle', 'text');
  wrap('strokeText', 'strokeStyle', 'text');
  wrap('fillRect', 'fillStyle', 'shape');
  wrap('fill', 'fillStyle', 'shape');
  wrap('stroke', 'strokeStyle', 'line');
  wrap('strokeRect', 'strokeStyle', 'line');
})();
