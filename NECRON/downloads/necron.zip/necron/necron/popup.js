const KEY = 'necron';
const DEFAULTS = { enabled: true, mode: 'smart', brightness: 35, sites: {}, listMode: 'except', siteList: [] };
const $ = (id) => document.getElementById(id);
let settings = DEFAULTS, host = null, path = '', seen = [];

const LM_HINTS = {
  except: 'The sites below are skipped (Necron stays off).',
  only: 'Necron runs only on the sites below.'
};

// Same matching rules as content.js
function norm(p) { return String(p).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/+$/, ''); }
function matches(entry, h, pth) {
  const p = norm(entry);
  if (!p) return false;
  const i = p.indexOf('/');
  let ph = (i < 0 ? p : p.slice(0, i)).replace(/^www\./, '');
  const pp = i < 0 ? '' : p.slice(i);
  h = h.replace(/^www\./, '');
  const ok = ph.startsWith('*.') ? (h === ph.slice(2) || h.endsWith('.' + ph.slice(2))) : h === ph;
  if (!ok) return false;
  return !pp || (pth || '').toLowerCase().startsWith(pp);
}
const isListed = () => settings.siteList.some((e) => matches(e, host, path));
function isOn() {
  if (!host || settings.enabled === false) return false;
  if ((settings.sites[host] || {}).enabled === false) return false;
  return settings.listMode === 'only' ? isListed() : !isListed();
}

async function save() { await chrome.storage.local.set({ [KEY]: settings }); }
function site() { settings.sites[host] = settings.sites[host] || {}; return settings.sites[host]; }

function addEntry(v) {
  v = norm(v);
  if (!v) return false;
  if (!settings.siteList.some((e) => norm(e) === v)) settings.siteList.push(v);
  return true;
}


function hostState(h) {
  const listed = settings.siteList.some((e) => matches(e, h, ''));
  const on = settings.listMode === 'only' ? listed : !listed;
  if (!on) return 'off';
  return 'smart';
}
function enableHost(h) {
  if (settings.listMode === 'except') settings.siteList = settings.siteList.filter((e) => !matches(e, h, ''));
  else if (!settings.siteList.some((e) => matches(e, h, ''))) addEntry(h);
}
function disableHost(h) {
  if (settings.listMode === 'except') { if (!settings.siteList.some((e) => matches(e, h, ''))) addEntry(h); }
  else settings.siteList = settings.siteList.filter((e) => !matches(e, h, ''));
}
async function setSiteState(h, st) {
  if (st === 'off') disableHost(h);
  else enableHost(h);
  await save(); render();
}
function renderSeen() {
  const ul = $('seenList');
  ul.innerHTML = '';
  const q = ($('search').value || '').trim().toLowerCase();
  let hosts = seen.slice();
  if (host && !hosts.includes(host)) hosts.unshift(host);
  hosts = hosts.filter((h) => !q || h.includes(q));
  // Sites that are on first
  hosts.sort((a, b) => (hostState(b) === 'smart') - (hostState(a) === 'smart'));
  if (!hosts.length) {
    const li = document.createElement('li'); li.className = 'empty'; li.textContent = q ? 'No match.' : 'Browse a few sites and they will show up here.'; ul.append(li);
  }
  hosts.slice(0, 150).forEach((h) => {
    const st = hostState(h);
    const li = document.createElement('li');
    const name = document.createElement('span'); name.className = 'hn'; name.textContent = h;
    const tri = document.createElement('div'); tri.className = 'tri';
    const TIPS = { smart: 'Necron makes this site dark.', off: 'Necron does nothing on this site.' };
    [['smart', 'On'], ['off', 'Off']].forEach(([k, label]) => {
      const bt = document.createElement('button'); bt.textContent = label; bt.title = TIPS[k];
      if (st === k) bt.classList.add('on');
      bt.onclick = () => setSiteState(h, k);
      tri.append(bt);
    });
    li.append(name, tri); ul.append(li);
  });
}

function renderList() {
  const ul = $('siteList');
  ul.innerHTML = '';
  if (!settings.siteList.length) {
    const li = document.createElement('li'); li.className = 'empty'; li.textContent = 'No sites listed yet.'; ul.append(li);
  }
  settings.siteList.forEach((entry, idx) => {
    const li = document.createElement('li');
    const span = document.createElement('span'); span.textContent = entry;
    const b = document.createElement('button'); b.textContent = '×'; b.title = 'Remove';
    b.onclick = async () => { settings.siteList.splice(idx, 1); await save(); render(); };
    li.append(span, b); ul.append(li);
  });

  renderSeen();
}

function render() {
  $('master').checked = settings.enabled !== false;
  $('brightness').value = settings.brightness;
  $('bnum').value = settings.brightness;
  const ok = !!host;
  $('host').textContent = host || 'Not available on this page';
  $('siteOn').checked = isOn();
  $('siteOn').disabled = !ok || settings.enabled === false;
  $('reset').disabled = !ok;
  $('addThis').disabled = !ok;
  document.querySelectorAll('#listMode button').forEach((b) => b.classList.toggle('on', b.dataset.lm === settings.listMode));
  $('lmHint').textContent = LM_HINTS[settings.listMode];
  renderList();
}

(async () => {
  const lg = $('logo');
  lg.onload = () => { lg.hidden = false; };
  lg.onerror = () => { lg.hidden = true; };
  lg.src = 'logo.png';
  const r = await chrome.storage.local.get([KEY, 'necron_seen']);
  seen = Array.isArray(r.necron_seen) ? r.necron_seen : [];
  settings = Object.assign({}, DEFAULTS, r[KEY] || {});
  settings.sites = settings.sites || {};
  settings.siteList = Array.isArray(settings.siteList) ? settings.siteList : [];
  // migrate old per-site "off" flags into the site list
  let migrated = false;
  for (const h of Object.keys(settings.sites)) {
    if (settings.sites[h].enabled === false) {
      if (settings.listMode === 'except') addEntry(h);
      delete settings.sites[h].enabled;
      if (!Object.keys(settings.sites[h]).length) delete settings.sites[h];
      migrated = true;
    }
  }
  if (migrated) await save();

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const u = new URL(tab.url);
    if (/^https?:$/.test(u.protocol)) { host = u.hostname; path = u.pathname; }
  } catch (e) {}
  render();

  // tabs
  document.querySelectorAll('.tabs button').forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
      $('tab-main').hidden = b.dataset.tab !== 'main';
      $('tab-list').hidden = b.dataset.tab !== 'list';
    };
  });

  $('master').onchange = async (e) => { settings.enabled = e.target.checked; await save(); render(); };

  $('siteOn').onchange = async (e) => {
    const want = e.target.checked;
    const matching = () => settings.siteList.filter((x) => matches(x, host, path));
    if (settings.listMode === 'except') {
      if (want) settings.siteList = settings.siteList.filter((x) => !matches(x, host, path));
      else addEntry(host);
    } else {
      if (want) addEntry(host);
      else settings.siteList = settings.siteList.filter((x) => !matches(x, host, path));
    }
    if (settings.sites[host]) delete settings.sites[host].enabled;
    await save(); render();
  };

  const setB = async (v) => {
    v = Math.max(0, Math.min(100, Math.round(+v)));
    if (isNaN(v)) return;
    settings.brightness = v; $('brightness').value = v; $('bnum').value = v;
    await save();
  };
  $('brightness').oninput = (e) => { $('bnum').value = e.target.value; };
  $('brightness').onchange = (e) => setB(e.target.value);
  $('bnum').onchange = (e) => setB(e.target.value);

  $('reset').onclick = async () => { delete settings.sites[host]; await save(); render(); };

  // site list tab
  document.querySelectorAll('#listMode button').forEach((b) => {
    b.onclick = async () => { settings.listMode = b.dataset.lm; await save(); render(); };
  });
  const doAdd = async () => {
    if (addEntry($('addInput').value)) { $('addInput').value = ''; await save(); render(); }
  };
  $('addBtn').onclick = doAdd;
  $('addInput').onkeydown = (e) => { if (e.key === 'Enter') doAdd(); };
  $('addThis').onclick = async () => { if (host && addEntry(host)) { await save(); render(); } };
  $('search').oninput = renderSeen;
  $('clearSeen').onclick = async () => { seen = []; await chrome.storage.local.set({ necron_seen: [] }); renderSeen(); };
  $('hotkey').onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }); };
})();
