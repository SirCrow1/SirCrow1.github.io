const KEY = 'necron';
const DEFAULTS = { enabled: true, mode: 'smart', brightness: 35, sites: {}, listMode: 'except', siteList: [] };
const $ = (id) => document.getElementById(id);
let settings = DEFAULTS, host = null, path = '';

const HINTS = {
  smart: 'Rewrites page colors. Images and video stay untouched. Best quality.',
  filter: 'Inverts the whole page and flips media back. Works on stubborn pages.'
};
const LM_HINTS = {
  except: 'Necron runs on every site except the ones listed.',
  only: 'Necron runs only on the sites listed.'
};

// Same matching rules as content.js
function norm(p) { return String(p).trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/+$/, ''); }
function matches(entry, h, pth) {
  const p = norm(entry);
  if (!p) return false;
  const i = p.indexOf('/');
  let ph = (i < 0 ? p : p.slice(0, i)).replace(/^www\./, '');
  const pp = i < 0 ? '' : p.slice(i);
  h = h.replace(/^www\./, '');
  const ok = ph.startsWith('*.') ? (h === ph.slice(2) || h.endsWith('.' + ph.slice(2))) : h === ph;
  if (!ok) return false;
  return !pp || (pth || '').toLowerCase().startsWith(pp);
}
const isListed = () => settings.siteList.some((e) => matches(e, host, path));
function isOn() {
  if (!host || settings.enabled === false) return false;
  if ((settings.sites[host] || {}).enabled === false) return false;
  return settings.listMode === 'only' ? isListed() : !isListed();
}

async function save() { await chrome.storage.local.set({ [KEY]: settings }); }
function site() { settings.sites[host] = settings.sites[host] || {}; return settings.sites[host]; }

function addEntry(v) {
  v = norm(v);
  if (!v) return false;
  if (!settings.siteList.some((e) => norm(e) === v)) settings.siteList.push(v);
  return true;
}

function renderList() {
  const ul = $('siteList');
  ul.innerHTML = '';
  if (!settings.siteList.length) {
    const li = document.createElement('li'); li.className = 'empty'; li.textContent = 'No sites listed yet.'; ul.append(li);
  }
  settings.siteList.forEach((entry, idx) => {
    const li = document.createElement('li');
    const span = document.createElement('span'); span.textContent = entry;
    const b = document.createElement('button'); b.textContent = '×'; b.title = 'Remove';
    b.onclick = async () => { settings.siteList.splice(idx, 1); await save(); render(); };
    li.append(span, b); ul.append(li);
  });

  const fl = $('filterList');
  fl.innerHTML = '';
  const hosts = Object.keys(settings.sites).filter((h) => settings.sites[h].mode === 'filter').sort();
  if (!hosts.length) {
    const li = document.createElement('li'); li.className = 'empty'; li.textContent = 'None yet. Pick Filter on the Main tab.'; fl.append(li);
  }
  hosts.forEach((h) => {
    const li = document.createElement('li');
    const span = document.createElement('span'); span.textContent = h;
    const b = document.createElement('button'); b.textContent = '×'; b.title = 'Back to Smart';
    b.onclick = async () => {
      delete settings.sites[h].mode;
      if (!Object.keys(settings.sites[h]).length) delete settings.sites[h];
      await save(); render();
    };
    li.append(span, b); fl.append(li);
  });
}

function render() {
  $('master').checked = settings.enabled !== false;
  $('brightness').value = settings.brightness;
  $('bnum').value = settings.brightness;
  const ok = !!host;
  $('host').textContent = host || 'Not available on this page';
  $('siteOn').checked = isOn();
  $('siteOn').disabled = !ok || settings.enabled === false;
  $('reset').disabled = !ok;
  $('addThis').disabled = !ok;
  const s = (ok && settings.sites[host]) || {};
  const mode = s.mode || settings.mode;
  document.querySelectorAll('#mode button').forEach((b) => b.classList.toggle('on', b.dataset.mode === mode));
  $('modeHint').textContent = HINTS[mode];
  document.querySelectorAll('#listMode button').forEach((b) => b.classList.toggle('on', b.dataset.lm === settings.listMode));
  $('lmHint').textContent = LM_HINTS[settings.listMode];
  renderList();
}

(async () => {
  const r = await chrome.storage.local.get(KEY);
  settings = Object.assign({}, DEFAULTS, r[KEY] || {});
  settings.sites = settings.sites || {};
  settings.siteList = Array.isArray(settings.siteList) ? settings.siteList : [];
  // migrate old per-site "off" flags into the site list
  let migrated = false;
  for (const h of Object.keys(settings.sites)) {
    if (settings.sites[h].enabled === false) {
      if (settings.listMode === 'except') addEntry(h);
      delete settings.sites[h].enabled;
      if (!Object.keys(settings.sites[h]).length) delete settings.sites[h];
      migrated = true;
    }
  }
  if (migrated) await save();

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const u = new URL(tab.url);
    if (/^https?:$/.test(u.protocol)) { host = u.hostname; path = u.pathname; }
  } catch (e) {}
  render();

  // tabs
  document.querySelectorAll('.tabs button').forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
      $('tab-main').hidden = b.dataset.tab !== 'main';
      $('tab-list').hidden = b.dataset.tab !== 'list';
    };
  });

  $('master').onchange = async (e) => { settings.enabled = e.target.checked; await save(); render(); };

  $('siteOn').onchange = async (e) => {
    const want = e.target.checked;
    const matching = () => settings.siteList.filter((x) => matches(x, host, path));
    if (settings.listMode === 'except') {
      if (want) settings.siteList = settings.siteList.filter((x) => !matches(x, host, path));
      else addEntry(host);
    } else {
      if (want) addEntry(host);
      else settings.siteList = settings.siteList.filter((x) => !matches(x, host, path));
    }
    if (settings.sites[host]) delete settings.sites[host].enabled;
    await save(); render();
  };

  document.querySelectorAll('#mode button').forEach((b) => {
    b.onclick = async () => { if (!host) return; site().mode = b.dataset.mode; await save(); render(); };
  });

  const setB = async (v) => {
    v = Math.max(0, Math.min(100, Math.round(+v)));
    if (isNaN(v)) return;
    settings.brightness = v; $('brightness').value = v; $('bnum').value = v;
    await save();
  };
  $('brightness').oninput = (e) => { $('bnum').value = e.target.value; };
  $('brightness').onchange = (e) => setB(e.target.value);
  $('bnum').onchange = (e) => setB(e.target.value);

  $('reset').onclick = async () => { delete settings.sites[host]; await save(); render(); };

  // site list tab
  document.querySelectorAll('#listMode button').forEach((b) => {
    b.onclick = async () => { settings.listMode = b.dataset.lm; await save(); render(); };
  });
  const doAdd = async () => {
    if (addEntry($('addInput').value)) { $('addInput').value = ''; await save(); render(); }
  };
  $('addBtn').onclick = doAdd;
  $('addInput').onkeydown = (e) => { if (e.key === 'Enter') doAdd(); };
  $('addThis').onclick = async () => { if (host && addEntry(host)) { await save(); render(); } };
  $('hotkey').onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }); };
})();
