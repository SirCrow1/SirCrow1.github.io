const $ = (s) => document.querySelector(s);
const listEl = $('#list'), emptyEl = $('#empty'), statusEl = $('#status');
const downloadBtn = $('#download'), wordBtn = $('#word'), toggleAll = $('#toggleAll');
const setButtons = (on) => { downloadBtn.disabled = wordBtn.disabled = !on; };

const HOSTS = ['gemini.google.com', 'chatgpt.com', 'chat.openai.com', 'claude.ai', 'claude.com',
  'copilot.microsoft.com', 'chat.deepseek.com', 'grok.com'];

let chat = null;
let boxes = [];

function setStatus(t) { statusEl.textContent = t || ''; }

function showEmpty(text) {
  chat = null;
  listEl.hidden = true;
  emptyEl.hidden = false;
  emptyEl.textContent = text;
  setButtons(false);
  toggleAll.disabled = true;
  $('#count').textContent = '';
}

function previewOf(msg) {
  return msg.blocks.map((b) => b.text).join(' ').replace(/\s+/g, ' ').slice(0, 160);
}

function updateCount() {
  const n = boxes.filter((b) => b.checked).length;
  $('#count').textContent = `${n} of ${boxes.length} selected`;
  setButtons(n > 0);
  toggleAll.checked = n === boxes.length;
  toggleAll.indeterminate = n > 0 && n < boxes.length;
}

function render() {
  listEl.hidden = false;
  emptyEl.hidden = true;
  toggleAll.disabled = false;
  $('#title').textContent = chat.title;
  listEl.replaceChildren();
  boxes = chat.messages.map((msg) => {
    const li = document.createElement('li');
    const label = document.createElement('label');
    const box = document.createElement('input');
    box.type = 'checkbox';
    box.checked = true;
    box.addEventListener('change', updateCount);
    const body = document.createElement('div');
    const who = document.createElement('div');
    who.className = 'who ' + msg.role;
    who.textContent = msg.role === 'user' ? 'Prompt' : 'Reply';
    const prev = document.createElement('div');
    prev.className = 'preview';
    prev.textContent = previewOf(msg);
    body.append(who, prev);
    label.append(box, body);
    li.append(label);
    listEl.append(li);
    return box;
  });
  updateCount();
}

async function load() {
  setStatus('');
  setButtons(false);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let host = '';
  try { host = new URL(tab.url).hostname; } catch (e) { /* no access to this tab */ }
  if (!HOSTS.some((h) => host === h || host.endsWith('.' + h))) {
    showEmpty('Open a chat on Gemini, ChatGPT, Claude, Copilot, DeepSeek or Grok, then click the extension again.');
    return;
  }
  try {
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractChat });
    chat = result;
  } catch (e) {
    showEmpty('Could not read this page: ' + e.message);
    return;
  }
  if (!chat || !chat.messages.length) {
    showEmpty('No messages found. Open a conversation and scroll through it so it loads, then click Rescan. If it still finds nothing, the site may have changed its layout.');
    return;
  }
  render();
}

toggleAll.addEventListener('change', () => {
  boxes.forEach((b) => { b.checked = toggleAll.checked; });
  updateCount();
});
$('#rescan').addEventListener('click', load);

async function save(kind) {
  const picked = chat.messages.filter((_, i) => boxes[i].checked);
  setButtons(false);
  setStatus(kind === 'pdf' ? 'Building PDF…' : 'Building Word file…');
  try {
    const blob = kind === 'pdf' ? await createPdf(chat.title, picked) : createDocx(chat.title, picked);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (chat.title.replace(/[\\/:*?"<>|]+/g, '').trim().slice(0, 80) || 'chat') + (kind === 'pdf' ? '.pdf' : '.docx');
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    setStatus(`Saved ${picked.length} message${picked.length === 1 ? '' : 's'}.`);
  } catch (e) {
    setStatus('Failed: ' + e.message);
  } finally {
    updateCount();
  }
}
downloadBtn.addEventListener('click', () => save('pdf'));
wordBtn.addEventListener('click', () => save('docx'));

load();
