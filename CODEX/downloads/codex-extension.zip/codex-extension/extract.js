// Injected into the Gemini tab by popup.js via chrome.scripting.executeScript({ func: extractChat }).
// It is serialized and run in the page, so it must be fully self-contained (no outside references).
// If Google changes Gemini's markup, the selectors in "messageRoots" below are the place to adjust.
async function extractChat(opts) {
  const SKIP_TAGS = new Set([
    'BUTTON', 'MAT-ICON', 'STYLE', 'SCRIPT', 'SVG', 'NOSCRIPT',
    'MODEL-THOUGHTS', 'SOURCES-CAROUSEL', 'SOURCES-CAROUSEL-INLINE',
    'TEXTAREA', 'INPUT', 'SELECT', 'NAV', 'ASIDE', 'FOOTER'
  ]);
  let genericMode = false;
  const INLINE_TAGS = new Set([
    'SPAN', 'B', 'STRONG', 'I', 'EM', 'A', 'CODE', 'SUB', 'SUP', 'MARK', 'U', 'S', 'DEL', 'SMALL', 'ABBR'
  ]);
  const BLOCK_SEL = 'p,h1,h2,h3,h4,h5,h6,ul,ol,li,pre,table,code-block,div,blockquote';

  const tag = (el) => el.tagName.toUpperCase();
  const skip = (el) =>
    SKIP_TAGS.has(tag(el)) ||
    el.classList.contains('cdk-visually-hidden') ||
    el.classList.contains('sr-only') ||
    el.classList.contains('visually-hidden') ||
    el.getAttribute('aria-hidden') === 'true' ||
    el.isContentEditable ||
    (genericMode && ['fixed', 'sticky'].includes(getComputedStyle(el).position));
  const clean = (s) =>
    s.replace(/[ \t\r\f\v\u00a0]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{3,}/g, '\n\n').trim();

  // Text of an inline-only subtree.
  function inline(node) {
    if (node.nodeType === 3) return node.nodeValue;
    if (node.nodeType !== 1) return '';
    if (node.dataset && node.dataset.math) return node.dataset.math; // rendered LaTeX -> source
    if (skip(node)) return '';
    if (tag(node) === 'BR') return '\n';
    let s = '';
    node.childNodes.forEach((c) => { s += inline(c); });
    return s;
  }

  function listItems(list, out, depth) {
    let n = 1;
    for (const li of list.children) {
      if (tag(li) !== 'LI') continue;
      const marker = tag(list) === 'OL' ? `${n++}.` : '\u2022';
      let buf = '';
      const nested = [];
      for (const ch of li.childNodes) {
        if (ch.nodeType === 1 && (tag(ch) === 'UL' || tag(ch) === 'OL')) nested.push(ch);
        else if (ch.nodeType === 1 && (tag(ch) === 'P' || tag(ch) === 'DIV')) buf += '\n' + inline(ch) + '\n';
        else buf += inline(ch);
      }
      const text = clean(buf);
      if (text) out.push({ type: 'li', text, marker, depth, src: li });
      nested.forEach((l) => listItems(l, out, depth + 1));
    }
  }

  function walk(el, out, depth) {
    let buf = '', bufSrc = null;
    const flush = () => {
      const t = clean(buf);
      if (t) out.push({ type: 'p', text: t, src: bufSrc || el });
      buf = ''; bufSrc = null;
    };
    for (const c of el.childNodes) {
      if (c.nodeType === 3) { buf += c.nodeValue; bufSrc = bufSrc || el; continue; }
      if (c.nodeType !== 1) continue;

      if (c.dataset && c.dataset.math) {
        if (c.classList.contains('math-block')) { flush(); out.push({ type: 'p', text: c.dataset.math, src: c }); }
        else { buf += c.dataset.math; bufSrc = bufSrc || c; }
        continue;
      }
      if (skip(c)) continue;

      const t = tag(c);
      if (/^H[1-6]$/.test(t)) {
        flush();
        const text = clean(inline(c));
        if (text) out.push({ type: 'h', level: Number(t[1]), text, src: c });
      } else if (t === 'PRE' || t === 'CODE-BLOCK') {
        flush();
        const code = c.querySelector('code') || c;
        const text = code.textContent.replace(/\n+$/, '');
        if (text.trim()) out.push({ type: 'code', text, src: c });
      } else if (t === 'UL' || t === 'OL') {
        flush();
        listItems(c, out, depth);
      } else if (t === 'TABLE') {
        flush();
        c.querySelectorAll('tr').forEach((tr, i) => {
          const cells = [...tr.children].map((td) => clean(inline(td)));
          if (cells.some(Boolean)) out.push({ type: 'row', text: cells.join('  |  '), header: i === 0, src: tr });
        });
      } else if (t === 'P') {
        flush();
        const text = clean(inline(c));
        if (text) out.push({ type: 'p', text, src: c });
      } else if (INLINE_TAGS.has(t) && !c.querySelector(BLOCK_SEL)) {
        buf += inline(c);
        bufSrc = bufSrc || c;
      } else {
        flush();
        walk(c, out, depth);
      }
    }
    flush();
  }

  // ---------------------------------------------------------------------------
  // Per-site message finders. Each returns [{ node, role, root }] in page order:
  //   node = the element for one message, role = 'user' | 'model',
  //   root = the element whose contents are the message text.
  // These selectors come from each site's own markup, which changes from time to
  // time. When a site stops working, this is the only block that needs editing.
  // ---------------------------------------------------------------------------
  const q = (sel) => [...document.querySelectorAll(sel)];

  const SITES = {
    gemini() {
      return q('user-query, model-response').map((node) => {
        const user = tag(node) === 'USER-QUERY';
        const root = user
          ? node.querySelector('.query-text') || node
          : node.querySelector('message-content') || node.querySelector('.markdown') || node;
        return { node, role: user ? 'user' : 'model', root };
      });
    },

    chatgpt() {
      // Layout from late September 2026: one [data-turn-key] holds a prompt and its reply.
      const fresh = q('[data-user-message-bubble], [data-markdown-text-style="assistant-message"]');
      if (fresh.length) {
        return fresh.map((node) => ({
          node, role: node.matches('[data-user-message-bubble]') ? 'user' : 'model', root: node }));
      }
      // Older layout.
      return q('[data-message-author-role]')
        .filter((n) => ['user', 'assistant'].includes(n.getAttribute('data-message-author-role')))
        .map((node) => {
          const user = node.getAttribute('data-message-author-role') === 'user';
          const root = user ? node.querySelector('.whitespace-pre-wrap') || node : node.querySelector('.markdown');
          return { node, role: user ? 'user' : 'model', root };
        })
        .filter((m) => m.root);
    },

    claude() {
      const USER = '[data-testid="user-message"], .font-user-message';
      const out = [];
      q(`${USER}, [data-testid="assistant-message"], .font-claude-response, .font-claude-message`)
        .filter((n) => !n.closest('[contenteditable="true"]'))
        .forEach((node) => {
          if (node.matches(USER)) { out.push({ node, role: 'user', root: node }); return; }
          // Only the written answer: tool-step and "thought process" summaries sit outside the markdown blocks.
          const md = [...node.querySelectorAll('.standard-markdown, .progressive-markdown')];
          const roots = md.filter((a) => !md.some((b) => b !== a && b.contains(a)));
          if (roots.length) roots.forEach((r) => out.push({ node: r, role: 'model', root: r }));
          else out.push({ node, role: 'model', root: node });
        });
      return out;
    },

    copilot() {
      const USER = '[data-content="user-message"], .fai-UserMessage__message, [data-testid="user-message"]';
      const AI = '[data-content="ai-message"], [data-testid="markdown-reply"], [data-testid="copilot-message-div"]';
      return q(`${USER}, ${AI}`).map((node) => ({ node, role: node.matches(USER) ? 'user' : 'model', root: node }));
    },

    // DeepSeek uses generated class names for prompts, so prompts are found by position:
    // the element just before each reply's turn. Least reliable of the six.
    deepseek() {
      const out = [];
      for (const md of q('.ds-markdown')) {
        if (md.closest('[class*="think" i]')) continue;
        let a = md.parentElement, prev = null;
        while (a && a !== document.body) {
          const p = a.previousElementSibling;
          if (p && p.innerText && p.innerText.trim() && !p.querySelector('.ds-markdown')) { prev = p; break; }
          a = a.parentElement;
        }
        if (prev && !out.some((o) => o.node === prev)) out.push({ node: prev, role: 'user', root: prev });
        out.push({ node: md, role: 'model', root: md });
      }
      return out;
    },

    // Grok: replies contain a markdown container, prompts do not. Least tested of the six.
    grok() {
      let nodes = q('[id^="response-"]');
      if (!nodes.length) nodes = q('.message-bubble');
      return nodes.map((node) => {
        const md = node.querySelector('.response-content-markdown');
        return { node, role: md ? 'model' : 'user', root: md || node.querySelector('.message-bubble') || node };
      });
    },
  };

  const host = location.hostname;
  const path = location.pathname;
  const siteKey =
    host === 'gemini.google.com' ? 'gemini' :
    /(^|\.)(chatgpt\.com|chat\.openai\.com)$/.test(host) ? 'chatgpt' :
    /(^|\.)claude\.(ai|com)$/.test(host) ? 'claude' :
    /(^|\.)copilot\.(com|microsoft\.com|cloud\.microsoft)$/.test(host) || host === 'm365.cloud.microsoft' ? 'copilot' :
    /(^|\.)deepseek\.com$/.test(host) ? 'deepseek' :
    host === 'grok.com' || (host === 'x.com' && path.startsWith('/i/grok')) ? 'grok' : null;

  const sortVisually = (found) => {
    found.forEach((f, n) => { f.n = n; f.rect = f.node.getBoundingClientRect(); });
    return found.sort((a, b) => (a.rect.height && b.rect.height ? a.rect.top - b.rect.top : 0) || a.n - b.n);
  };
  const itemOf = (role, blocks, node) => {
    const text = blocks.map((b) => b.text).join('\n');
    return { role, blocks, node, key: role + '|' + text.length + '|' + text.slice(0, 120) };
  };

  // The element that scrolls the chat (the biggest scrollable area on the page).
  const findScroller = () => {
    let best = null, bestH = 0;
    for (const el of document.querySelectorAll('div, main, section')) {
      if (el.scrollHeight > el.clientHeight + 10 && el.clientWidth > innerWidth * 0.4 && el.scrollHeight > bestH &&
          /(auto|scroll)/.test(getComputedStyle(el).overflowY)) { best = el; bestH = el.scrollHeight; }
    }
    return best || document.scrollingElement || document.documentElement;
  };

  // Fallback that needs no site selectors: read everything in the chat area and decide who wrote each
  // block by where it sits. Your prompts are the short right-aligned bubbles; replies start at the left edge.
  const STATUS = /^(worked|thought|thinking|reasoned|searched|analy[sz]ed|researched)\b[^\n]{0,40}$/i;
  const genericItems = () => {
    genericMode = true;
    try {
      let root = findScroller();
      if (root === document.scrollingElement || root === document.documentElement) root = document.body;
      while (root.children.length === 1 && !skip(root.children[0])) root = root.children[0];
      const blocks = [];
      walk(root, blocks, 0);
      const live = blocks.filter((b) => b.src && !(b.text.length < 48 && STATUS.test(b.text)));
      live.forEach((b, n) => {
        const r = document.createRange();
        r.selectNodeContents(b.src);
        let t = r.getBoundingClientRect();
        if (!t.width) t = b.src.getBoundingClientRect();
        b.r = { left: t.left, right: t.right, top: t.top }; b.n = n;
      });
      live.sort((a, b) => a.r.top - b.r.top || a.n - b.n);
      const left = Math.min(...live.map((b) => b.r.left)), right = Math.max(...live.map((b) => b.r.right));
      const w = Math.max(1, right - left);
      const out = [];
      for (const b of live) {
        const role = b.r.left - left > 0.25 * w && b.r.right > right - 0.12 * w ? 'user' : 'model';
        const last = out[out.length - 1];
        if (last && last.role === role) last.blocks.push(b);
        else out.push({ role, blocks: [b] });
      }
      return out.map((g) => itemOf(g.role, g.blocks, root));
    } catch (e) {
      return [];
    } finally {
      genericMode = false;
    }
  };

  const bothRoles = (list) => new Set(list.map((i) => i.role)).size === 2;

  const siteItems = () => {
    let found = siteKey ? SITES[siteKey]() : [];
    // Keep only the outermost match when one match sits inside another.
    found = found.filter((a) => !found.some((b) => b !== a && b.node.contains(a.node)));
    const out = [];
    for (const { role, root, node } of sortVisually(found)) {
      const blocks = [];
      walk(root, blocks, 0);
      if (blocks.length) out.push(itemOf(role, blocks, node));
    }
    return out;
  };

  const collectItems = () => {
    if (siteKey === 'grok') { // no verified selectors for Grok: go by position first
      const g = genericItems();
      return bothRoles(g) ? g : siteItems().length ? siteItems() : g;
    }
    const found = siteItems();
    if (bothRoles(found)) return found;
    const g = genericItems(); // the site's markup changed and prompts/replies could not be told apart
    return bothRoles(g) ? g : found.length ? found : g;
  };

  let items = collectItems();

  // Long chats: sites only keep a window of messages in the page. Scroll through the whole chat
  // and remember every message seen (overlapping windows are matched up so nothing repeats).
  if (opts && opts.scrollAll && items.length) {
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const scrollable = (el) => /(auto|scroll)/.test(getComputedStyle(el).overflowY) && el.scrollHeight > el.clientHeight + 10;
    let sc = document.querySelector('[data-app-action-timeline-scroll]');
    if (!sc) {
      sc = items[0].node.parentElement;
      while (sc && sc !== document.body && !scrollable(sc)) sc = sc.parentElement;
    }
    if (!sc || sc === document.body) sc = findScroller();
    // In an upside-down list (column-reverse) scrollTop is 0 at the newest end and negative going up.
    const reversed = getComputedStyle(sc).flexDirection === 'column-reverse';
    const endTop = () => (reversed ? 0 : sc.scrollHeight - sc.clientHeight); // scrollTop at the newest end
    const fromEnd = endTop() - sc.scrollTop;
    const t0 = Date.now(), LIMIT = 90000;

    let lastH = -1, same = 0; // 1) go to the oldest end until older messages stop loading
    while (same < 3 && Date.now() - t0 < LIMIT / 2) {
      sc.scrollTop = -1e9;
      await sleep(700);
      if (sc.scrollHeight === lastH) same++; else { same = 0; lastH = sc.scrollHeight; }
    }

    const acc = []; // 2) walk back toward the newest end, collecting each window
    const addWindow = (win) => {
      let keep = -1;
      for (let j = acc.length - 1; j >= 0 && keep < 0; j--) {
        const L = Math.min(win.length, acc.length - j);
        let ok = true;
        for (let t = 0; t < L; t++) if (acc[j + t].key !== win[t].key) { ok = false; break; }
        if (ok) keep = L;
      }
      acc.push(...win.slice(keep < 0 ? 0 : keep));
    };
    const step = Math.max(200, sc.clientHeight * 0.6);
    sc.scrollTop = -1e9;
    await sleep(400);
    for (let guard = 0; ; guard++) {
      addWindow(collectItems());
      if (sc.scrollTop >= endTop() - 4 || guard > 600 || Date.now() - t0 > LIMIT) break;
      const before = sc.scrollTop;
      sc.scrollTop = before + step;
      await sleep(250);
      if (sc.scrollTop === before) break; // cannot move any further
    }
    sc.scrollTop = endTop() - fromEnd; // put the page back where it was
    if (acc.length) items = acc;
  }

  const messages = [];
  const plain = (blocks) => blocks.map(({ src, r, n, ...rest }) => rest);
  for (const { role, blocks } of items) {
    const last = messages[messages.length - 1];
    if (last && last.role === role) last.blocks.push(...plain(blocks)); // one reply split over several elements
    else messages.push({ role, blocks: plain(blocks) });
  }

  const BRAND = '(?:Google )?Gemini|ChatGPT|Claude|(?:Microsoft )?Copilot|DeepSeek|Grok';
  let title = document.title
    .replace(new RegExp('\\s*[-\u2013\u2014|\u00b7]\\s*(' + BRAND + ')\\s*$', 'i'), '')
    .replace(new RegExp('^\\s*(' + BRAND + ')\\s*[-\u2013\u2014|\u00b7]\\s*', 'i'), '')
    .trim();
  if (new RegExp('^(' + BRAND + ')$', 'i').test(title)) title = '';
  return { site: siteKey, title: title || 'Chat', messages };
}


// Short description of how the current page marks up its messages, for fixing a site that doesn't work.
// Runs inside the page. Contains only tag/class/attribute names and the first few characters of each block.
function describePage() {
  const SEL = '[data-message-author-role],[data-turn-key],[data-user-message-bubble],[data-markdown-text-style],' +
    '[data-content],[data-testid],[id^="response"],[class*="message"],[class*="user"],[class*="assistant"],' +
    '[class*="response"],[class*="bubble"],[class*="markdown"],[class*="query"],[class*="turn"],article,[role="article"]';
  const rows = [];
  const vw = window.innerWidth || 1;
  for (const el of document.querySelectorAll(SEL)) {
    if (rows.length >= 70) break;
    const text = (el.innerText || '').replace(/\s+/g, ' ').trim();
    const r = el.getBoundingClientRect();
    if (!text || text.length > 4000 || !r.width) continue;
    let depth = 0;
    for (let p = el.parentElement; p; p = p.parentElement) depth++;
    const cls = [...el.classList].slice(0, 5).map((c) => c.slice(0, 30)).join('.');
    const attrs = [...el.attributes]
      .filter((a) => a.name.startsWith('data-') || a.name === 'role')
      .map((a) => `${a.name}="${a.value.slice(0, 24)}"`).join(' ');
    rows.push(`${el.tagName.toLowerCase()}${el.id ? '#' + el.id.slice(0, 24) : ''}${cls ? '.' + cls : ''} ${attrs} ` +
      `d=${depth} x=${Math.round((r.left / vw) * 100)}-${Math.round((r.right / vw) * 100)} len=${text.length} "${text.slice(0, 25)}"`);
  }
  return `${location.hostname}${location.pathname.replace(/[0-9a-f-]{20,}/gi, '…')} | ${document.title}\n` + rows.join('\n');
}
