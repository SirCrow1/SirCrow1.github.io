C.O.D.E.X (Chat Output & Document Export Xchange)
=================================================
Install: open brave://extensions (or chrome://extensions), turn on Developer mode,
click "Load unpacked", choose this folder.

Works on: gemini.google.com, chatgpt.com, claude.ai, copilot.microsoft.com,
          chat.deepseek.com, grok.com

If a site shows "No messages found":
  1. Scroll through the chat so it loads, then click Rescan.
  2. If still empty, the site changed its page layout. Edit the SITES block near the
     bottom of extract.js (one small function per site), and reload the extension.

Export formats: PDF, Word, Markdown, plain text, HTML, PNG image, JSON, or Copy as text.

Files
  manifest.json  extension settings        popup.*   the popup window
  extract.js     reads messages per site   pdf.js     PDF export
  docx.js        Word export               formats.js  Markdown / text / HTML / JSON               icons/    toolbar icons
