// Text-based exporters: Markdown, plain text, HTML, JSON. Prompts are marked as quotes / shaded boxes;
// there are no author labels, dates or branding.

const joinLines = (a) => a.join('\n').replace(/\n{3,}/g, '\n\n').trim();
const quote = (t) => t.split('\n').map((l) => (l ? '> ' + l : '>')).join('\n');
const mdMarker = (m) => (m === '\u2022' ? '-' : m);

function bodyText(msg, md) {
  const out = [];
  let prev = null;
  for (const b of msg.blocks) {
    if ((prev === 'li' || prev === 'row') && prev !== b.type) out.push('');
    if (b.type === 'h') out.push(md ? '#'.repeat(Math.min(b.level, 6)) + ' ' + b.text : b.text, '');
    else if (b.type === 'li') out.push('  '.repeat(b.depth) + (md ? mdMarker(b.marker) : b.marker) + ' ' + b.text.replace(/\n/g, ' '));
    else if (b.type === 'code') out.push(...(md ? ['```', b.text, '```'] : b.text.split('\n').map((l) => '    ' + l)), '');
    else if (b.type === 'row') {
      const cells = b.text.split('  |  ');
      if (md) {
        out.push('| ' + cells.join(' | ') + ' |');
        if (b.header) out.push('|' + cells.map(() => ' --- ').join('|') + '|');
      } else out.push(b.text);
    } else out.push(md ? b.text.replace(/\n/g, '  \n') : b.text, '');
    prev = b.type;
  }
  return joinLines(out);
}

function textOf(messages, md) {
  return messages.map((m) => (m.role === 'user' ? quote(bodyText(m, md)) : bodyText(m, md))).join('\n\n') + '\n';
}
const toMarkdown = (messages) => new Blob([textOf(messages, true)], { type: 'text/markdown;charset=utf-8' });
const toText = (messages) => new Blob([textOf(messages, false)], { type: 'text/plain;charset=utf-8' });

function toJson(messages) {
  const data = { messages: messages.map((m) => ({ role: m.role === 'user' ? 'prompt' : 'reply', text: bodyText(m, false) })) };
  return new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
}

function toHtml(messages) {
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  let html = '';
  for (const m of messages) {
    html += `<section class="${m.role === 'user' ? 'u' : 'r'}">`;
    let table = false;
    for (const b of m.blocks) {
      if (table && b.type !== 'row') { html += '</table>'; table = false; }
      if (b.type === 'h') html += `<h${Math.min(b.level + 1, 4)}>${esc(b.text)}</h${Math.min(b.level + 1, 4)}>`;
      else if (b.type === 'li') html += `<p class="li" style="margin-left:${b.depth * 22}px"><span>${esc(b.marker)}</span>${esc(b.text)}</p>`;
      else if (b.type === 'code') html += `<pre><code>${esc(b.text)}</code></pre>`;
      else if (b.type === 'row') {
        if (!table) { html += '<table>'; table = true; }
        const cell = b.header ? 'th' : 'td';
        html += '<tr>' + b.text.split('  |  ').map((c) => `<${cell}>${esc(c)}</${cell}>`).join('') + '</tr>';
      } else html += `<p>${esc(b.text)}</p>`;
    }
    if (table) html += '</table>';
    html += '</section>';
  }
  const doc = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Chat</title><style>
body{font:16px/1.6 system-ui,-apple-system,"Segoe UI",Helvetica,Arial,sans-serif;color:#222;max-width:780px;margin:32px auto;padding:0 18px}
section{padding:2px 0;margin-bottom:22px}section.r{border-bottom:1px solid #e3e5e8}
section.u{background:#eef3fb;border-left:3px solid #1a5fd0;padding:8px 18px;margin-bottom:22px}
p{margin:0 0 10px}p.li{margin-bottom:4px}p.li span{display:inline-block;width:1.4em}
h2,h3,h4{margin:18px 0 6px;line-height:1.3}pre{background:#f3f4f6;padding:10px 12px;overflow:auto;font-size:13px}
code{font-family:Menlo,Consolas,"Courier New",monospace}table{border-collapse:collapse;margin:8px 0 12px}
td,th{border:1px solid #d6d9de;padding:5px 10px;text-align:left}th{background:#f3f4f6}
</style></head><body>${html}</body></html>`;
  return new Blob([doc], { type: 'text/html;charset=utf-8' });
}
