// Injected into the Gemini tab by popup.js via chrome.scripting.executeScript({ func: extractChat }).
// It is serialized and run in the page, so it must be fully self-contained (no outside references).
// If Google changes Gemini's markup, the selectors in "messageRoots" below are the place to adjust.
async function extractChat(opts) {
  const SKIP_TAGS = new Set([
    'BUTTON', 'MAT-ICON', 'STYLE', 'SCRIPT', 'SVG', 'NOSCRIPT',
    'MODEL-THOUGHTS', 'SOURCES-CAROUSEL', 'SOURCES-CAROUSEL-INLINE'
  ]);
  const INLINE_TAGS = new Set([
    'SPAN', 'B', 'STRONG', 'I', 'EM', 'A', 'CODE', 'SUB', 'SUP', 'MARK', 'U', 'S', 'DEL', 'SMALL', 'ABBR'
  ]);
  const BLOCK_SEL = 'p,h1,h2,h3,h4,h5,h6,ul,ol,li,pre,table,code-block,div,blockquote';

  const tag = (el) => el.tagName.toUpperCase();
  const skip = (el) =>
    SKIP_TAGS.has(tag(el)) ||
    el.classList.contains('cdk-visually-hidden') ||
    el.classList.contains('sr-only') ||
    el.classList.contains('visually-hidden') ||
    el.getAttribute('aria-hidden') === 'true';
  const clean = (s) =>
    s.replace(/[ \t\r\f\v\u00a0]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{3,}/g, '\n\n').trim();

  // Text of an inline-only subtree.
  function inline(node) {
    if (node.nodeType === 3) return node.nodeValue;
    if (node.nodeType !== 1) return '';
    if (node.dataset && node.dataset.math) return node.dataset.math; // rendered LaTeX -> source
    if (skip(node)) return '';
    if (tag(node) === 'BR') return '\n';
    let s = '';
    node.childNodes.forEach((c) => { s += inline(c); });
    return s;
  }

  function listItems(list, out, depth) {
    let n = 1;
    for (const li of list.children) {
      if (tag(li) !== 'LI') continue;
      const marker = tag(list) === 'OL' ? `${n++}.` : '\u2022';
      let buf = '';
      const nested = [];
      for (const ch of li.childNodes) {
        if (ch.nodeType === 1 && (tag(ch) === 'UL' || tag(ch) === 'OL')) nested.push(ch);
        else if (ch.nodeType === 1 && (tag(ch) === 'P' || tag(ch) === 'DIV')) buf += '\n' + inline(ch) + '\n';
        else buf += inline(ch);
      }
      const text = clean(buf);
      if (text) out.push({ type: 'li', text, marker, depth });
      nested.forEach((l) => listItems(l, out, depth + 1));
    }
  }

  function walk(el, out, depth) {
    let buf = '';
    const flush = () => {
      const t = clean(buf);
      if (t) out.push({ type: 'p', text: t });
      buf = '';
    };
    for (const c of el.childNodes) {
      if (c.nodeType === 3) { buf += c.nodeValue; continue; }
      if (c.nodeType !== 1) continue;

      if (c.dataset && c.dataset.math) {
        if (c.classList.contains('math-block')) { flush(); out.push({ type: 'p', text: c.dataset.math }); }
        else buf += c.dataset.math;
        continue;
      }
      if (skip(c)) continue;

      const t = tag(c);
      if (/^H[1-6]$/.test(t)) {
        flush();
        const text = clean(inline(c));
        if (text) out.push({ type: 'h', level: Number(t[1]), text });
      } else if (t === 'PRE' || t === 'CODE-BLOCK') {
        flush();
        const code = c.querySelector('code') || c;
        const text = code.textContent.replace(/\n+$/, '');
        if (text.trim()) out.push({ type: 'code', text });
      } else if (t === 'UL' || t === 'OL') {
        flush();
        listItems(c, out, depth);
      } else if (t === 'TABLE') {
        flush();
        c.querySelectorAll('tr').forEach((tr, i) => {
          const cells = [...tr.children].map((td) => clean(inline(td)));
          if (cells.some(Boolean)) out.push({ type: 'row', text: cells.join('  |  '), header: i === 0 });
        });
      } else if (t === 'P') {
        flush();
        const text = clean(inline(c));
        if (text) out.push({ type: 'p', text });
      } else if (INLINE_TAGS.has(t) && !c.querySelector(BLOCK_SEL)) {
        buf += inline(c);
      } else {
        flush();
        walk(c, out, depth);
      }
    }
    flush();
  }

  // ---------------------------------------------------------------------------
  // Per-site message finders. Each returns [{ node, role, root }] in page order:
  //   node = the element for one message, role = 'user' | 'model',
  //   root = the element whose contents are the message text.
  // These selectors come from each site's own markup, which changes from time to
  // time. When a site stops working, this is the only block that needs editing.
  // ---------------------------------------------------------------------------
  const q = (sel) => [...document.querySelectorAll(sel)];

  const SITES = {
    gemini() {
      return q('user-query, model-response').map((node) => {
        const user = tag(node) === 'USER-QUERY';
        const root = user
          ? node.querySelector('.query-text') || node
          : node.querySelector('message-content') || node.querySelector('.markdown') || node;
        return { node, role: user ? 'user' : 'model', root };
      });
    },

    chatgpt() {
      return q('[data-message-author-role]')
        .filter((n) => ['user', 'assistant'].includes(n.getAttribute('data-message-author-role')))
        .map((node) => {
          const user = node.getAttribute('data-message-author-role') === 'user';
          const root = user ? node.querySelector('.whitespace-pre-wrap') || node : node.querySelector('.markdown');
          return { node, role: user ? 'user' : 'model', root };
        })
        .filter((m) => m.root);
    },

    claude() {
      const USER = '[data-testid="user-message"], .font-user-message';
      const out = [];
      q(`${USER}, [data-testid="assistant-message"], .font-claude-response, .font-claude-message`)
        .filter((n) => !n.closest('[contenteditable="true"]'))
        .forEach((node) => {
          if (node.matches(USER)) { out.push({ node, role: 'user', root: node }); return; }
          // Only the written answer: tool-step and "thought process" summaries sit outside the markdown blocks.
          const md = [...node.querySelectorAll('.standard-markdown, .progressive-markdown')];
          const roots = md.filter((a) => !md.some((b) => b !== a && b.contains(a)));
          if (roots.length) roots.forEach((r) => out.push({ node: r, role: 'model', root: r }));
          else out.push({ node, role: 'model', root: node });
        });
      return out;
    },

    copilot() {
      const USER = '[data-content="user-message"], [data-testid="user-message"]';
      return q(`${USER}, [data-content="ai-message"], [data-testid="copilot-message-div"]`)
        .map((node) => ({ node, role: node.matches(USER) ? 'user' : 'model', root: node }));
    },

    // DeepSeek uses generated class names for prompts, so prompts are found by position:
    // the element just before each reply's turn. Least reliable of the six.
    deepseek() {
      const out = [];
      for (const md of q('.ds-markdown')) {
        if (md.closest('[class*="think" i]')) continue;
        let a = md.parentElement, prev = null;
        while (a && a !== document.body) {
          const p = a.previousElementSibling;
          if (p && p.innerText && p.innerText.trim() && !p.querySelector('.ds-markdown')) { prev = p; break; }
          a = a.parentElement;
        }
        if (prev && !out.some((o) => o.node === prev)) out.push({ node: prev, role: 'user', root: prev });
        out.push({ node: md, role: 'model', root: md });
      }
      return out;
    },

    // Grok: replies contain a markdown container, prompts do not. Least tested of the six.
    grok() {
      let nodes = q('[id^="response-"]');
      if (!nodes.length) nodes = q('.message-bubble');
      return nodes.map((node) => {
        const md = node.querySelector('.response-content-markdown');
        return { node, role: md ? 'model' : 'user', root: md || node.querySelector('.message-bubble') || node };
      });
    },
  };

  const host = location.hostname;
  const siteKey =
    host === 'gemini.google.com' ? 'gemini' :
    /(^|\.)(chatgpt\.com|chat\.openai\.com)$/.test(host) ? 'chatgpt' :
    /(^|\.)claude\.(ai|com)$/.test(host) ? 'claude' :
    host === 'copilot.microsoft.com' ? 'copilot' :
    /(^|\.)deepseek\.com$/.test(host) ? 'deepseek' :
    host === 'grok.com' ? 'grok' : null;

  const collectItems = () => {
    let found = siteKey ? SITES[siteKey]() : [];
    // Keep only the outermost match when one match sits inside another.
    found = found.filter((a) => !found.some((b) => b !== a && b.node.contains(a.node)));
    const out = [];
    for (const { role, root, node } of found) {
      const blocks = [];
      walk(root, blocks, 0);
      if (!blocks.length) continue;
      const text = blocks.map((b) => b.text).join('\n');
      out.push({ role, blocks, node, key: role + '|' + text.length + '|' + text.slice(0, 120) });
    }
    return out;
  };

  let items = collectItems();

  // Long chats: sites only keep a window of messages in the page. Scroll through the whole chat
  // and remember every message seen (overlapping windows are matched up so nothing repeats).
  if (opts && opts.scrollAll && items.length) {
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const scrollable = (el) => /(auto|scroll)/.test(getComputedStyle(el).overflowY) && el.scrollHeight > el.clientHeight + 10;
    let sc = items[0].node.parentElement;
    while (sc && sc !== document.body && !scrollable(sc)) sc = sc.parentElement;
    if (!sc || sc === document.body) sc = document.scrollingElement || document.documentElement;
    const fromBottom = sc.scrollHeight - sc.scrollTop;
    const t0 = Date.now(), LIMIT = 90000;

    let lastH = -1, same = 0; // 1) go to the top until older messages stop loading
    while (same < 3 && Date.now() - t0 < LIMIT / 2) {
      sc.scrollTop = 0;
      await sleep(700);
      if (sc.scrollHeight === lastH) same++; else { same = 0; lastH = sc.scrollHeight; }
    }

    const acc = []; // 2) walk back down, collecting each window
    const addWindow = (win) => {
      let keep = -1;
      for (let j = acc.length - 1; j >= 0 && keep < 0; j--) {
        const L = Math.min(win.length, acc.length - j);
        let ok = true;
        for (let t = 0; t < L; t++) if (acc[j + t].key !== win[t].key) { ok = false; break; }
        if (ok) keep = L;
      }
      acc.push(...win.slice(keep < 0 ? 0 : keep));
    };
    const step = Math.max(200, sc.clientHeight * 0.6);
    sc.scrollTop = 0;
    await sleep(400);
    for (let guard = 0; ; guard++) {
      addWindow(collectItems());
      if (sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 4 || guard > 600 || Date.now() - t0 > LIMIT) break;
      sc.scrollTop += step;
      await sleep(250);
    }
    sc.scrollTop = Math.max(0, sc.scrollHeight - fromBottom); // put the page back where it was
    if (acc.length) items = acc;
  }

  const messages = [];
  for (const { role, blocks } of items) {
    const last = messages[messages.length - 1];
    if (last && last.role === role) last.blocks.push(...blocks); // one reply split over several elements
    else messages.push({ role, blocks });
  }

  const BRAND = '(?:Google )?Gemini|ChatGPT|Claude|(?:Microsoft )?Copilot|DeepSeek|Grok';
  let title = document.title
    .replace(new RegExp('\\s*[-\u2013\u2014|\u00b7]\\s*(' + BRAND + ')\\s*$', 'i'), '')
    .replace(new RegExp('^\\s*(' + BRAND + ')\\s*[-\u2013\u2014|\u00b7]\\s*', 'i'), '')
    .trim();
  if (new RegExp('^(' + BRAND + ')$', 'i').test(title)) title = '';
  return { site: siteKey, title: title || 'Chat', messages };
}
