const $ = (s) => document.querySelector(s);
const HOSTS = ['gemini.google.com', 'chatgpt.com', 'chat.openai.com', 'claude.ai', 'claude.com',
  'copilot.microsoft.com', 'chat.deepseek.com', 'grok.com'];

const FORMATS = {
  pdf:  { label: 'PDF document (.pdf)',   ext: 'pdf',  make: (t, m) => createPdf(t, m) },
  docx: { label: 'Word document (.docx)', ext: 'docx', make: (t, m) => createDocx(t, m) },
  md:   { label: 'Markdown (.md)',        ext: 'md',   make: (t, m) => toMarkdown(m) },
  txt:  { label: 'Plain text (.txt)',     ext: 'txt',  make: (t, m) => toText(m) },
  html: { label: 'Web page (.html)',      ext: 'html', make: (t, m) => toHtml(m) },
  png:  { label: 'Image (.png)',          ext: 'png',  make: (t, m) => createImage(m) },
  json: { label: 'JSON data (.json)',     ext: 'json', make: (t, m) => toJson(m) },
};

const listEl = $('#list'), emptyEl = $('#empty'), statusEl = $('#status');
const downloadBtn = $('#download'), copyBtn = $('#copy'), formatEl = $('#format'), sortBtn = $('#sort');
const toggleAll = $('#toggleAll'), searchEl = $('#search'), noMatchEl = $('#nomatch');
const store = {
  get: (k, d) => { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } },
};

let chat = null;
let selected = new Set();
let newestFirst = true; // always open with the latest chat first
let boxes = new Map(); // message index -> checkbox
let groupBoxes = []; // { box, idxs }
let rows = new Map(), previews = new Map(), chatEls = [];
let fullText = [], lowText = [];

const setStatus = (t) => { statusEl.textContent = t || ''; };
const setButtons = (on) => { downloadBtn.disabled = copyBtn.disabled = !on; };

// Chats = a prompt plus its replies, numbered oldest (1) to newest. Shown newest-first or oldest-first.
function groupsOf() {
  const groups = [];
  chat.messages.forEach((m, i) => {
    if (m.role === 'user' || !groups.length) groups.push([i]);
    else groups[groups.length - 1].push(i);
  });
  return groups;
}
function displayOrder() {
  const g = groupsOf();
  return (newestFirst ? g.reverse() : g).flat();
}
const pickedMessages = () => displayOrder().filter((i) => selected.has(i)).map((i) => chat.messages[i]);

// ----- search -----
const terms = () => searchEl.value.toLowerCase().split(/\s+/).filter(Boolean);
const matches = (i, t) => t.every((w) => lowText[i].includes(w));
const visibleIdx = () => { const t = terms(); return chat.messages.map((_, i) => i).filter((i) => matches(i, t)); };
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function setPreview(i, t) {
  const el = previews.get(i);
  if (!t.length) { el.textContent = fullText[i].slice(0, 160); return; }
  const pos = Math.min(...t.map((w) => lowText[i].indexOf(w)).filter((p) => p >= 0));
  const start = Math.max(0, pos - 40), end = start + 170;
  el.replaceChildren();
  if (start > 0) el.append('…');
  const re = new RegExp('(' + t.map(escapeRe).join('|') + ')', 'ig');
  fullText[i].slice(start, end).split(re).forEach((part, k) => {
    if (k % 2) { const m = document.createElement('mark'); m.textContent = part; el.append(m); }
    else el.append(part);
  });
  if (end < fullText[i].length) el.append('…');
}

function applyFilter() {
  if (!chat) return;
  const t = terms();
  let shown = 0;
  rows.forEach((row, i) => {
    const ok = matches(i, t);
    row.hidden = !ok;
    if (ok) { shown++; setPreview(i, t); }
  });
  chatEls.forEach(({ el, idxs }) => { el.hidden = !idxs.some((i) => matches(i, t)); });
  noMatchEl.hidden = shown > 0;
  listEl.hidden = shown === 0;
  $('#allLabel').textContent = t.length ? 'Select shown' : 'Select all';
  if (t.length) setStatus(`${shown} of ${chat.messages.length} messages match.`);
  updateCount();
}

function showEmpty(text) {
  chat = null;
  listEl.hidden = true;
  emptyEl.hidden = false;
  emptyEl.textContent = text;
  setButtons(false);
  toggleAll.disabled = true;
  $('#count').textContent = '';
}


function updateCount() {
  const total = chat.messages.length, t = terms();
  $('#count').textContent = `${selected.size} of ${total}`;
  setButtons(selected.size > 0);
  const vis = visibleIdx();
  const k = vis.filter((i) => selected.has(i)).length;
  toggleAll.checked = vis.length > 0 && k === vis.length;
  toggleAll.indeterminate = k > 0 && k < vis.length;
  for (const { box, idxs } of groupBoxes) {
    const v = idxs.filter((i) => matches(i, t));
    const c = v.filter((i) => selected.has(i)).length;
    box.checked = v.length > 0 && c === v.length;
    box.indeterminate = c > 0 && c < v.length;
  }
}

function render() {
  listEl.hidden = false;
  emptyEl.hidden = true;
  toggleAll.disabled = false;
  sortBtn.textContent = newestFirst ? 'Newest first' : 'Oldest first';
  sortBtn.setAttribute('aria-label', 'Order: ' + sortBtn.textContent + '. Click to switch.');
  listEl.replaceChildren();
  boxes = new Map();
  groupBoxes = [];
  rows = new Map();
  previews = new Map();
  chatEls = [];
  const all = groupsOf();
  const numbered = all.map((idxs, n) => ({ idxs, num: n + 1 }));
  for (const { idxs, num } of newestFirst ? numbered.reverse() : numbered) {
    // Header row for this chat: number, tag and a checkbox for the whole chat.
    const wrap = document.createElement('li');
    wrap.className = 'chat';
    const head = document.createElement('div');
    head.className = 'group';
    const gl = document.createElement('label');
    const gbox = document.createElement('input');
    gbox.type = 'checkbox';
    gbox.setAttribute('aria-label', `Select chat ${num}`);
    gbox.addEventListener('change', () => {
      const t = terms();
      idxs.filter((i) => matches(i, t)).forEach((i) => { gbox.checked ? selected.add(i) : selected.delete(i); boxes.get(i).checked = gbox.checked; });
      updateCount();
    });
    const numEl = document.createElement('span');
    numEl.className = 'num';
    numEl.textContent = `Chat ${num}`;
    gl.append(gbox, numEl);
    if (all.length > 1 && (num === all.length || num === 1)) {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = num === all.length ? 'Latest' : 'First';
      gl.append(tag);
    }
    head.append(gl);
    wrap.append(head);
    groupBoxes.push({ box: gbox, idxs });

    for (const i of idxs) {
      const msg = chat.messages[i];
      const li = document.createElement('div');
      li.className = 'msg';
      const label = document.createElement('label');
      const box = document.createElement('input');
      box.type = 'checkbox';
      box.checked = selected.has(i);
      box.addEventListener('change', () => { box.checked ? selected.add(i) : selected.delete(i); updateCount(); });
      const body = document.createElement('div');
      const who = document.createElement('div');
      who.className = 'who ' + msg.role;
      who.textContent = msg.role === 'user' ? 'Prompt' : 'Reply';
      const prev = document.createElement('div');
      prev.className = 'preview';
      previews.set(i, prev);
      rows.set(i, li);
      body.append(who, prev);
      label.append(box, body);
      li.append(label);
      wrap.append(li);
      boxes.set(i, box);
    }
    listEl.append(wrap);
    chatEls.push({ el: wrap, idxs });
  }
  applyFilter();
  listEl.scrollTop = newestFirst ? 0 : listEl.scrollHeight; // the latest chat is always what you see first
}

async function load(scrollAll = false) {
  setStatus('');
  setButtons(false);
  if (scrollAll) setStatus('Scrolling through the chat to load every message… keep this open (up to a minute).');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let host = '';
  try { host = new URL(tab.url).hostname; } catch (e) { /* no access to this tab */ }
  if (!HOSTS.some((h) => host === h || host.endsWith('.' + h))) {
    showEmpty('Open a chat on Gemini, ChatGPT, Claude, Copilot, DeepSeek or Grok, then click the extension again.');
    return;
  }
  try {
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractChat, args: [{ scrollAll }] });
    chat = result;
  } catch (e) {
    showEmpty('Could not read this page: ' + e.message);
    return;
  }
  if (!chat || !chat.messages.length) {
    showEmpty('No messages found. Open a conversation and scroll through it so it loads, then click Rescan. If it still finds nothing, the site may have changed its layout.');
    return;
  }
  fullText = chat.messages.map((m) => m.blocks.map((b) => b.text).join(' ').replace(/\s+/g, ' ').trim());
  lowText = fullText.map((s) => s.toLowerCase());
  selected = new Set(chat.messages.map((_, i) => i));
  render();
  setStatus(scrollAll ? `Loaded ${chat.messages.length} messages.` : 'Long chat? Click “Load all” to capture every message.');
}

function saveBlob(blob, ext) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = (chat.title.replace(/[\\/:*?"<>|]+/g, '').trim().slice(0, 80) || 'chat') + '.' + ext;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

async function download() {
  const fmt = FORMATS[formatEl.value];
  const picked = pickedMessages();
  setButtons(false);
  setStatus('Building ' + fmt.ext.toUpperCase() + '…');
  try {
    saveBlob(await fmt.make(chat.title, picked), fmt.ext);
    setStatus(`Saved ${picked.length} message${picked.length === 1 ? '' : 's'}.`);
  } catch (e) {
    setStatus('Failed: ' + e.message);
  } finally {
    updateCount();
  }
}

async function copy() {
  try {
    await navigator.clipboard.writeText(await toText(pickedMessages()).text());
    setStatus('Copied as plain text.');
  } catch (e) {
    setStatus('Could not copy: ' + e.message);
  }
}

for (const [key, f] of Object.entries(FORMATS)) formatEl.append(new Option(f.label, key));
const savedFormat = store.get('codex.format', 'pdf');
formatEl.value = FORMATS[savedFormat] ? savedFormat : 'pdf';
formatEl.addEventListener('change', () => store.set('codex.format', formatEl.value));

toggleAll.addEventListener('change', () => {
  for (const i of visibleIdx()) toggleAll.checked ? selected.add(i) : selected.delete(i);
  boxes.forEach((b, i) => { b.checked = selected.has(i); });
  updateCount();
});
searchEl.addEventListener('input', () => { setStatus(''); applyFilter(); });
searchEl.addEventListener('keydown', (e) => { if (e.key === 'Escape' && searchEl.value) { e.preventDefault(); searchEl.value = ''; setStatus(''); applyFilter(); } });
sortBtn.addEventListener('click', () => {
  newestFirst = !newestFirst;
  render();
});
$('#rescan').addEventListener('click', () => load(false));
$('#loadall').addEventListener('click', async () => {
  $('#loadall').disabled = true;
  await load(true);
  $('#loadall').disabled = false;
});
downloadBtn.addEventListener('click', download);
copyBtn.addEventListener('click', copy);

load(false);
