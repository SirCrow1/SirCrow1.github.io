// Minimal PDF writer, no libraries.
// Each page is drawn on a <canvas> and embedded as a JPEG, so any language, emoji or
// symbol renders correctly. Trade-off: text in the PDF is not selectable or searchable.

const PAGE = { w: 595, h: 842, margin: 48, scale: 2 }; // A4 in points; scale = pixel density
const SANS = '"Helvetica Neue", Helvetica, Arial, "Segoe UI", "Noto Sans", sans-serif';
const MONO = 'Menlo, Consolas, "Courier New", monospace';

function buildPdf(pages, pw, ph) {
  const enc = new TextEncoder();
  const chunks = [];
  const offsets = [];
  let len = 0;
  const push = (d) => {
    const b = typeof d === 'string' ? enc.encode(d) : d;
    chunks.push(b);
    len += b.length;
  };
  const obj = (n, body) => {
    offsets[n] = len;
    push(`${n} 0 obj\n${body}\nendobj\n`);
  };

  push('%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, `<< /Type /Pages /Kids [${pages.map((_, i) => `${3 + 3 * i} 0 R`).join(' ')}] /Count ${pages.length} >>`);

  pages.forEach((p, i) => {
    const page = 3 + 3 * i, content = page + 1, img = page + 2;
    obj(page, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] ` +
      `/Resources << /XObject << /Im0 ${img} 0 R >> >> /Contents ${content} 0 R >>`);
    const stream = `q ${pw} 0 0 ${ph} 0 0 cm /Im0 Do Q`;
    obj(content, `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
    offsets[img] = len;
    push(`${img} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${p.width} /Height ${p.height} ` +
      `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.bytes.length} >>\nstream\n`);
    push(p.bytes);
    push('\nendstream\nendobj\n');
  });

  const count = 3 + 3 * pages.length;
  const xrefAt = len;
  let xref = `xref\n0 ${count}\n0000000000 65535 f \n`;
  for (let i = 1; i < count; i++) xref += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  xref += `trailer\n<< /Size ${count} /Root 1 0 R >>\nstartxref\n${xrefAt}\n%%EOF\n`;
  push(xref);
  return new Blob(chunks, { type: 'application/pdf' });
}

async function renderDoc(messages, keep) {
  const { w: PW, h: PH, margin: M, scale: S } = PAGE;
  const CW = PW - 2 * M;
  const pending = [];
  let cv, ctx, y;
  let tint = null;      // background band while drawing a prompt (user) message
  let ix = M, iw = CW;  // inner x / width of the current message

  const finishPage = () => {
    if (!cv) return;
    const c = cv;
    if (keep) { pending.push(c); return; }
    pending.push(new Promise((resolve) =>
      c.toBlob(async (b) => resolve({ bytes: new Uint8Array(await b.arrayBuffer()), width: c.width, height: c.height }),
        'image/jpeg', 0.92)));
  };
  const newPage = () => {
    finishPage(); // snapshot is taken now, so the old canvas can be released
    cv = document.createElement('canvas');
    cv.width = PW * S;
    cv.height = PH * S;
    ctx = cv.getContext('2d');
    ctx.scale(S, S);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, PW, PH);
    y = M;
  };
  const ensure = (h) => { if (y + h > PH - M) newPage(); };
  const band = (h) => {
    ctx.fillStyle = tint; ctx.fillRect(M, y, CW, h);
    ctx.fillStyle = '#1a5fd0'; ctx.fillRect(M, y, 3, h);
  };
  const gap = (h) => {
    if (tint) { ensure(h); band(h); }
    y += h;
  };
  const pad = (bg, h) => {
    ensure(h);
    if (tint) band(h); else { ctx.fillStyle = bg; ctx.fillRect(M, y, CW, h); }
    y += h;
  };

  const measure = (s, font) => { ctx.font = font; return ctx.measureText(s).width; };

  // Word wrap for prose; falls back to character breaks for long words / CJK text.
  function wrapWords(text, font, width) {
    const out = [];
    for (const para of text.split('\n')) {
      if (!para.trim()) { out.push(''); continue; }
      let line = '';
      for (const tok of para.match(/\S+\s*|\s+/g)) {
        if (measure((line + tok).trimEnd(), font) <= width) { line += tok; continue; }
        if (line) { out.push(line.trimEnd()); line = ''; }
        if (measure(tok.trimEnd(), font) <= width) { line = tok; continue; }
        for (const ch of Array.from(tok)) {
          if (line && measure(line + ch, font) > width) { out.push(line); line = ch; }
          else line += ch;
        }
      }
      if (line) out.push(line.trimEnd());
    }
    return out;
  }

  // Hard wrap for code, keeps whitespace.
  function wrapChars(text, font, width) {
    const out = [];
    for (const raw of text.replace(/\t/g, '    ').split('\n')) {
      if (measure(raw, font) <= width) { out.push(raw); continue; }
      let line = '';
      for (const ch of Array.from(raw)) {
        if (line && measure(line + ch, font) > width) { out.push(line); line = ch; }
        else line += ch;
      }
      out.push(line);
    }
    return out;
  }

  function lines(arr, o) {
    arr.forEach((l, idx) => {
      ensure(o.lh);
      if (tint) band(o.lh);
      if (o.bg) { ctx.fillStyle = o.bg; ctx.fillRect(M, y, CW, o.lh); }
      ctx.font = o.font;
      ctx.fillStyle = o.color;
      const base = y + o.lh * 0.5 + o.size * 0.35;
      if (idx === 0 && o.marker) ctx.fillText(o.marker, o.x, base);
      ctx.fillText(l, o.x + (o.markerW || 0), base);
      y += o.lh;
    });
  }

  const BODY = `11px ${SANS}`, BOLD = `bold 11px ${SANS}`;

  newPage();

  // No header: the page starts straight with the messages (no title, date or branding).

  for (const msg of messages) {
    const isUser = msg.role === 'user';
    ensure(50);
    if (isUser) { tint = '#eef3fb'; ix = M + 12; iw = CW - 24; pad(tint, 6); }
    else { tint = null; ix = M; iw = CW; }

    for (const b of msg.blocks) {
      if (b.type === 'h') {
        const size = { 1: 17, 2: 14.5, 3: 12.5 }[b.level] || 11.5;
        const font = `bold ${size}px ${SANS}`;
        gap(5);
        lines(wrapWords(b.text, font, iw), { font, size, lh: size * 1.35, color: '#111111', x: ix });
        gap(2);
      } else if (b.type === 'li') {
        lines(wrapWords(b.text, BODY, iw - b.depth * 18 - 16), {
          font: BODY, size: 11, lh: 16, color: '#222222', x: ix + b.depth * 18, marker: b.marker, markerW: 16 });
        gap(2);
      } else if (b.type === 'code') {
        const font = `9.5px ${MONO}`;
        gap(3);
        pad('#f3f4f6', 5);
        lines(wrapChars(b.text, font, iw - 16), { font, size: 9.5, lh: 13, color: '#1f2933', x: ix + 8, bg: '#f3f4f6' });
        pad('#f3f4f6', 5);
        gap(5);
      } else if (b.type === 'row') {
        const font = b.header ? BOLD : BODY;
        lines(wrapWords(b.text, font, iw), { font, size: 11, lh: 16, color: '#222222', x: ix });
        gap(1);
      } else {
        lines(wrapWords(b.text, BODY, iw), { font: BODY, size: 11, lh: 16, color: '#222222', x: ix });
        gap(6);
      }
    }

    if (isUser) {
      gap(2); pad(tint, 6);
      tint = null; ix = M; iw = CW;
      gap(12);
    } else {
      gap(6);
      ensure(2);
      ctx.fillStyle = '#e3e5e8';
      ctx.fillRect(M, y, CW, 0.75);
      gap(12);
    }
  }

  finishPage();
  if (keep) return { canvases: pending, endY: y };
  return Promise.all(pending);
}

async function createPdf(title, messages) {
  return buildPdf(await renderDoc(messages, false), PAGE.w, PAGE.h);
}

// One tall PNG (like a long screenshot) built from the same layout as the PDF.
async function createImage(messages) {
  const { canvases, endY } = await renderDoc(messages, true);
  if (canvases.length > 16) throw new Error(`Too long for one image (${canvases.length} pages). Select fewer messages or use PDF.`);
  const S = PAGE.scale, m = PAGE.margin * S, usable = (PAGE.h - 2 * PAGE.margin) * S;
  const W = canvases[0].width;
  const heights = canvases.map((_, i) => (i < canvases.length - 1 ? usable : Math.max(1, Math.ceil(endY * S - m))));
  const total = 2 * m + heights.reduce((a, b) => a + b, 0);
  const out = document.createElement('canvas');
  out.width = W; out.height = total;
  const c = out.getContext('2d');
  c.fillStyle = '#ffffff'; c.fillRect(0, 0, W, total);
  canvases.forEach((cv, i) => c.drawImage(cv, 0, m, W, heights[i], 0, m + i * usable, W, heights[i]));
  return new Promise((res) => out.toBlob(res, 'image/png'));
}
